# Bot 批跑排障参考

本文件记录 BlastGame Bot 批跑过程中遇到过的故障及其排查方法。新增故障时追加到末尾。

---

## 故障清单

### 2026-07-01：Unity .asset YAML 缩进错误

**现象**：所有批跑结果均为 100% WR（winCount=runCount, failCount=0, failBucketDistribution 全零）。批次在 1-2 秒内完成全部档位。

**根因**：`DynamicDifficultyConfigs:` 下的 `- StartDifficulty:` 使用了 2 空格缩进，但 Unity YAML 解析器要求 4 空格。Unity 解析失败时静默降级为默认配置（无难度），导致 Bot 瞬间通关。

**排查过程**：
1. 先怀疑是参数配置本身问题（恢复已知好用的 L80 variant A 配置 → 仍然 100%）
2. 发现 `read_asset_combo` 返回 9 个配置而不是 5 个（残留旧数据）
3. 修复残留后仍 100% → 发现是缩进问题
4. 修正到 4/6 空格后恢复正常

**证据**：
- 修复前：L80 T1=100%（400局全通）
- 修复后：L80 T1=92%（正常值）

**修复脚本**：`Doc/AI/multi-tier-designer/scripts/fix_asset_patch.py`（final version）

### 2026-07-01：大批次 AssetDatabase.Refresh 耗时

**现象**：修改 31 个 asset 文件后提交批跑，等了 6 分钟才有反应。

**根因**：Unity 的 `AssetDatabase.Refresh(ForceUpdate)` 需要重扫描所有修改过的 asset 文件。31 个文件同时修改耗时 ~6 分钟。

**教训**：改完 asset 文件后不要立即提交 bot 请求。等 Editor 编译/刷新完成（Unity 进程 CPU 稳定后再提交）。
