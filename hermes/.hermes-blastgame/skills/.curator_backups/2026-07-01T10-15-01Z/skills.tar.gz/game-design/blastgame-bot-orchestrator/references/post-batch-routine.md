# Batch 完成后的例行操作

每次 Unity Bot 批跑完成后，按此清单执行。

## 0. 检测批次完成（不轮询）

监控 `BuildLogs/auto-batch-last-export.txt` 的 mtime：

```python
old_mtime = os.stat("BuildLogs/auto-batch-last-export.txt").st_mtime
while os.stat("BuildLogs/auto-batch-last-export.txt").st_mtime == old_mtime:
    time.sleep(1)
# mtime 变了 → 批次完成
```

脚本 `~/.hermes/scripts/monitor_bot.py` 在后台运行，检测到变化后自动关弹窗、读结果、打标记。

## 1. 关闭 Explorer 弹窗

Unity 用 EditorUtility.RevealInFinder 打开输出目录。每次跑完关掉：

```powershell
powershell -Command '(New-Object -ComObject Shell.Application).Windows() | Where-Object { $_.LocationURL -like "*telemetry*" } | ForEach-Object { $_.Quit() }'
```

## 2. 读取结果

## 2. 读取结果

```python
from token_saver import tsv_batch
table = tsv_batch(csv_t3, csv_t4, csv_t5, csv_t1, csv_t2)
print(table)
```

## 3. 规则判定

```python
from token_saver import rule_check
for each level:
    ck = rule_check(t1, t3, t5, diff)
    print(f"L{lv}: {'✅' if ck['pass'] else '❌'} {ck['reasons']}")
```

## 4. 报告——必须用表格展示完整胜率

```markdown
| 档位 | 胜率 | 期望次数 | 配置 |
|:----:|:----:|:--------:|------|
| T1=T2 | xx% | x.xx | sd=xx, sc=x, ratios=... |
| T3 | xx% | x.xx (+x.xx) | ... |
| T4=T5 | xx% | x.xx (+x.xx) | ... |

| 档差 | 差值 | 体感评估 |
|:----:|:----:|:--------:|
| T1→T3 | xx% | +x.xx 次 |
| T3→T5 | xx% | +x.xx 次 |
```

禁止用文字叙述或代码块代替表格。

## 5. 合格则入库

```bash
python batch_export_excel.py import_config.json
```

## 6. 提交下一关

```json
{ "levelSpec": "{next_level}", "runCount": 400, "tiersCsv": "1,2,3,4,5", ... }
```
