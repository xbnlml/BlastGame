---
name: blastgame-bot-orchestrator
description: "BlastGame Bot 批跑工作流 — 触发 Unity Bot 批跑、读取 telemetry 结果、分析胜率数据"
category: game-design
---

# BlastGame Bot 批跑工作流

## 触发条件
- Unity Editor **已打开**、无编译 Error
- 目标 asset 配置已写入 `Assets/GameModule/GameMain/ConfigSo/Generated_enum/test/*.asset`
- Bot 请求文件就绪（见下方格式）

## 🚦 提交前预检清单（每次必须执行）

```markdown
1️⃣ 先 patch asset → 验证格式正确（4空格缩进、5个配置）
2️⃣ 再写 auto-batch-request.json
3️⃣ 确认请求被拾取（文件消失）
4️⃣ 启动 monitor_bot.py 后台
5️⃣ 确认 Unity CPU 在增长
```

**顺序不能反。** 先写请求再 patch asset → Unity AssetDatabase.Refresh 读到旧配置，白白浪费一轮。

一条都不能跳过。不检查就提交 → 大概率白跑。

## 批次完成后处理

### 读取结果 → 关弹窗 → 清理失败数据

```python
# 读取（用 Python csv 模块，不用 cut）
import csv
with open(csv_path) as f:
    for row in csv.reader(f):
        wr = float(row[6])  # winkate

# 关弹窗
powershell -Command '(New-Object -ComObject Shell.Application).Windows() | Where-Object { $_.LocationURL -like "*telemetry*" } | ForEach-Object { $_.Quit() }'

# 如果数据作废（批次中断/配置错误），删除该批次目录
rm -rf telemetry/bot/{错误批次目录}
```

### 监控批跑完成（推荐用 monitor_bot.py）

`~/.hermes/scripts/monitor_bot.py` 监控 `BuildLogs/auto-batch-last-export.txt` 的 mtime 变化：

```bash
# 提交批次后启动
cd BlastGame && python ~/AppData/Local/hermes/scripts/monitor_bot.py

# 后台模式（推荐）
cd BlastGame && python ~/AppData/Local/hermes/scripts/monitor_bot.py &
```

脚本会：
1. 记录当前 mtime → 循环 sleep(1)
2. mtime 变化 → 读取结果 → 关弹窗 → 打印摘要
3. `RESULT_SUCCESS=True/False` + 导出路径

**不用 cron 轮询**。不消耗 CPU。


### 提交后确认队列（必须全部通过）
```
[ ] 请求文件被拾取（BuildLogs/auto-batch-request.json 已不存在）
[ ] Editor 日志出现批跑记录（grep "Bot Batch" Editor.log）
[ ] telemetry 出现新批次目录（ls -lt telemetry/bot/ | head -3）
[ ] Unity CPU 在增长（batch mode 进程 CPU 时间 > 2分钟）
```

### 批次完成后的例行清理（必须执行）

### 🔍 CSV 读取陷阱（2026-07-01 L67 误读事故）

**绝对不要用 `cut -d,` 或 `awk` 读 CSV。** CSV 的引号字段（如 `failBucketDistribution`）内含逗号，`cut` 不认引号，会误把分布数值当成 winkate，导致全盘误读。

```bash
# ❌ 错误 — 引号内逗号导致列偏移
cut -d, -f7 campaign-summary-L67-T1.csv   # 读到的是 0.17(分布值), 不是 73.5%(winkate)

# ✅ 正确 — 用 Python csv 模块
python -c "
import csv
with open('...campaign-summary-*.csv') as f:
    for row in csv.reader(f):
        print(row[6])  # winkate 在最后一列
"
```

L67 因此全盘误读，浪费大量时间排查。用此技能后不得再犯。
Unity 跑完 Bot 后会弹出一个 Windows Explorer 窗口指向输出目录。
**每次跑完后执行（优先用 COM 方法，更可靠）：**
```powershell
# 方法 A：COM Shell.Application（推荐，匹配更准）
powershell -Command '(New-Object -ComObject Shell.Application).Windows() | Where-Object { $_.LocationURL -like "*telemetry*" } | ForEach-Object { $_.Quit() }'

# 方法 B：Get-Process（备用）
powershell -Command 'Get-Process explorer | Where-Object MainWindowTitle -like "*telemetry*" | ForEach-Object { $_.CloseMainWindow() }'
```

### 批次卡死或失败的排查步骤
1. 检查 CPU 时间：batch 子进程 CPU < 2 分钟 → 可能卡了
2. 检查 Editor 日志：`tail -30 Editor.log | grep "Bot Batch"`
3. 检查 MAX_PATH：levelSpec 太长会导致写 CSV 时 DirectoryNotFoundException
4. 检查 YAML 缩进：asset 缩进错误会导致全 100% WR
5. 尝试 touch 一个脚本文件触发 Unity 重编译

---

## 📝 auto-batch-request.json 格式

## 📝 auto-batch-request.json 格式

写入 `BuildLogs/auto-batch-request.json`：

```json
{
  "levelSpec": "80",
  "runCount": 400,
  "levelFolder": "test",
  "tiersCsv": "1,2,3,4,5",
  "recordReplay": false,
  "tag": "l80-v1"
}
```

| 字段 | 说明 |
|------|------|
| `levelSpec` | **单关最安全**。可逗号分隔（如 `"80,83"`），**禁止用 `-` 范围** |
| `runCount` | 入库验收 400；探测 150；对比 200 |
| `levelFolder` | 固定 `"test"` |
| `tiersCsv` | Normal 验收 `"1,3,5"`；Hard/SH 验收 `"1,2,3,4,5"` |
| `tag` | 自定义标记，用于区分批次 |

### ⚠️ 路径长度限制

Windows MAX_PATH = 260 字符。`levelSpec` 长度超过 ~10 字符可能导致目录/文件名超限，写 CSV 时 `DirectoryNotFoundException` 整批作废。**单关 `"80"` 最安全。**

## 确认真在跑

```bash
# 1. 请求文件被拾取
ls BuildLogs/auto-batch-request.json   # 不存在 = 已拾取

# 2. Editor 日志出现批跑记录
grep "Bot Batch" ~/AppData/Local/Unity/Editor/Editor.log | tail -3

# 3. telemetry 目录出现新批次
ls -lt telemetry/bot/ | head -3

# 4. Unity 进程有 CPU 占用（batch mode 两个进程）
powershell -Command "Get-Process Unity | Select-Object Id, @{N='CPUmin';E={[math]::Round(\$_.TotalProcessorTime.TotalMinutes,1)}}"
```

## 弹窗清理

Bot 跑完后 Unity 弹出输出目录窗口。每次跑完后关掉：

```powershell
Get-Process explorer | Where-Object MainWindowTitle -like "*telemetry*" | ForEach-Object { $_.CloseMainWindow() }
```

`tiersCsv` 按关卡类型：
| 类型 | 成品验收 | 探测/补缺 |
|------|---------|----------|
| Normal | `1,3,5`（T1/T3/T5 足够） | `1,2,3,4,5` 或 `3,4,5` |
| Hard | `1,2,3,4,5`（全档） | 同上 |

### 结果文件
Unity 的 `BlastBotAutoBatchTrigger` 自动拾取请求文件执行。结果写入 `BuildLogs/auto-batch-result.json`：
```json
{
  "success": true,
  "outDir": "C:\\...\\telemetry\\bot\\{levelSpec}-{timestamp}\\...",
  "error": "",
  "finishedUtc": "..."
}
```

---

## 监控批跑进度

批跑可能持续 30-60 分钟。使用 cron job + watchdog 监控：
```bash
# 1. 写监控脚本 -> ~/.hermes/scripts/watchdog_bot_batch.py
# 2. 创建 cron job（每5分钟检查）
hermes cron create --name bot-watchdog --schedule "every 5m" --script watchdog_bot_batch.py --no-agent
```
watchdog 脚本逻辑：
- 无结果文件 → 静默（还在跑）
- `success=true` → 打印 ✅ + tag
- `success=false` → 打印 ❌ + 错误原因

**注意**：TUI/CLI 会话不支持 cron 消息实时推送。看结果需要用 `hermes cron list` 或直接读文件。

---

## 读取结果

### 批次完成后的例行清理
Unity 跑完 Bot 后会弹出一个 Windows Explorer 窗口指向 telemetry 目录。**必须关闭它**，否则窗口堆积。

```bash
powershell -Command 'Get-Process explorer | Where-Object MainWindowTitle -like "*telemetry*" | ForEach-Object { $_.CloseMainWindow() }'
```

### 目录结构
```
telemetry/bot/{levelSpec}-{timestamp}/
├── L{levelSpec}-T{n}-{timestamp}-batch-range/
│   ├── campaign-summary-L{levelSpec}-T{n}.csv    ← 各关胜率汇总
│   └── campaign-attempts-L{levelSpec}-T{n}.csv    ← 每局明细
└── auto-batch-result.json
```

### CSV 读取（省 token 方式）

**不要用 `read_file` 一行行读 CSV**。在 `execute_code` 里用 pandas 或 `token_saver` 一次处理：

```python
# 方式 A：token_saver 紧凑输出（推荐）
from token_saver import tsv_batch
table = tsv_batch(csv_t3, csv_t4, csv_t5, csv_t1, csv_t2)
print(table)  # 7关数据 ≈ 400 字符

# 方式 B：pandas 自由分析
import pandas as pd
df = pd.read_csv("...campaign-summary-*.csv")
print(df[["level", "winkate"]].to_string(index=False))
```

### campaign-summary.csv 关键列
| 列 | 含义 |
|----|------|
| `level` | 关卡号 |
| `DifficultyLevel` | 0=Normal, 1=Hard, 2=SuperHard |
| `winkate` | **胜率（0~1）** — 入库判定的唯一真源 |
| `winCount` / `failCount` | 通关/失败局数 |
| `failBucketDistribution` | 失败进度分布（逗号分隔 10 桶） |

### 样本量精度（95% 置信）
| 局数 n | p≈50% ± | p≈80% ± | 适用 |
|--------|---------|---------|------|
| 150 | ~10% | ~8% | 粗筛/探测 |
| 200 | ~7% | ~5.5% | 候选对比 |
| **300** | **~5.6%** | **~4.5%** | **入库验收（默认）** |
| **400** | **~5%** | **~4%** | **⭐ 入库验收标准（必须）** |

### Tag 命名约定
- `final-verify-rN` — 最终 400 局入库验收（r1, r2...）
- `fix-combo-verify-rN` — 补缺组合验证（如 variant A/B 验证）
- `slot-probe-rN` — 五槽位探测
- `round3-baseline` — round3 基线批跑

同一批关卡可能跑过多轮，按时间戳区分：
- 较早的轮次可能是 baseline（round3 旧配置）
- 较新的轮次可能是 patch 后的验证跑
- **读取时务必确认 tag 和目录时间**

---

## ⚠️ Bot 版本漂移检测

**问题**：Bot 有 bug 时不会立即暴露，但会导致之前所有数据作废。
**解法**：在每次 `auto-batch-request.json` 的 `levelSpec` 中混入 3 关**基准关**
（推荐 L55、L84、L88，各跑 T1/T3/T5 100局），用于检测 Bot 行为是否漂移。

待实现脚本：`sanity_check.py`，功能：
1. 从本次跑数中提取基准关胜率
2. 对比历史基线（存 JSON）
3. 偏差 >8% 时标红报警

在没有 `sanity_check.py` 之前，手动在 levelSpec 尾部添加基准关，分析时人工对照即可。

---

## 关键脚本

| 脚本 | 用途 |
|------|------|
| `Doc/AI/multi-tier-designer/scripts/batch_analyze.py` | 批量判定（读 telemetry 目录出表） |
| `Doc/AI/multi-tier-designer/scripts/token_saver.py` | 紧凑 CSV 输出/规则检查 |
| `Doc/AI/multi-tier-designer/scripts/watchdog_bot_batch.py` | 批跑完成监控脚本 |

## 注意事项
- Bot 策略固定为 **VisibleGreedy**（beam search）
- 每局独立种子：`seed = level×1000 + runCount + runIndex×17`
- Workbench 批跑默认开启拟人误触（`disableHumanExecutionNoise`），会加宽波动
- 评判以点估计 `winkate` 为准，允许相邻档 ≤1% 视为持平

## ⚠️ Windows MAX_PATH 限制：批次大小必须 ≤ 5 关

**Windows 路径最大 260 字符。** Unity Bot 导出路径：
```
telemetry/bot/{levelSpec}-{timestamp}/
  L{levelSpec}-T{n}-{timestamp}-batch-range/
    campaign-summary-{levelSpec}-T{n}.csv
```

`levelSpec` 过长 → 全路径超 260 → `DirectoryNotFoundException` → 跑完无法写 CSV，结果丢失。

| levelSpec | 长度 | 结果 |
|-----------|:----:|:----:|
| `"80"` | 2 | ✅ 正常 |
| `"52,53,56"` | 9 | ✅ 正常 |
| `"51,52,53,56,60,64,66,67,70,74,76,77,78,79,81,83,86,89,93,94,99"` | 58 | ❌ 炸了 |
| `"51-100"` | 6 | ⚠️ 范围格式可能跳过实际运行 |

**规则**：单批 ≤ **5 关**，用逗号分隔。**不要用 `-` 范围格式**（不保证触发实际运行）。

### 数据存档约定

所有中间结果存到 `D:\download\Hermes`，**不放在工程文件夹**。

```
D:\download\Hermes\
├── INDEX.md           ← 总进度表
├── L{关号}\
│   └── README.md      ← 该关所有历史批次、配置、胜率、判定
```

每个 README.md 包含：
- 难度、目标胜率
- 每次批次的配置+实际 Bot 胜率
- 成品方案（已入库的）
- 数据时效性标记（版本/日期）

### 🎯 最佳实践：一关一关跑

用户确认的跑法——**每次只提交 1 关**，跑完立即分析、入库、提交下一关。优势：
- 路径最短（不可能触 MAX_PATH）
- 出错时只损失 1 关的时间
- 单关 5 档 × 400 局 ≈ 15-20 分钟

```json
// 推荐格式——单关
{ "levelSpec": "74", "runCount": 400, "tiersCsv": "1,2,3,4,5", ... }
```\n\n### 🔬 探针模式\n\nNormal 关 5 槽位只需 3 套参数（T1=T2, T3, T4=T5），多出槽位可放候选配置一次跑完：\n1. 从 Phase1 挑 5 个不同配置，各占一槽\n2. 提交一次 400 局（tiersCsv: 1,2,3,4,5）\n3. 从实际 Bot 结果中挑 3 组成品\n4. 成品再验一轮\n\n**探针不关心配对规则**，所有槽都放不同候选，先拿数据再拼成品。

### 数据评估核心方法（2026-07-01 用户纠正）

**用期望通关次数 = 1 / 胜率，不用百分比差额。**

| 胜率区间 | 体感 | 参考差 | 期望差 |
|:-------:|------|:-----:|:------:|
| >70% | 需很大差才感 | ~20% | +0.3~0.5 |
| 50-70% | 需明显差距 | ~15% | +0.3~0.5 |
| <30% | 小差已够 | >5% | 已足够 |

**相邻档跨度 ≤ 40% 是指每对相邻档之间，不是 T1-T5 总跨度。**

### 数据分析优先级（2026-07-01 用户纠正）

当 Summary 五档不满足要求时的排查顺序：
1. **先看 Phase2 candidates**（有 200 局，比 Phase1 的 100 局更可靠）
2. 不行才翻 Phase1 raw（自由组合搜索）
3. 不行才跑新探针

不要跳过 Phase2 直接去 Phase1。\n\nPhase1 仅 80-100 局，胜率标签不准确，同配置出现在 Phase1 和 summary 中且有不同 WR 则说明是采样波动，以次数高的为准。\n最终必须经 Bot 400 局验证才能入库。\n\n---

### 现象 A：批跑瞬间完成，全部 100% WR

**根因**：Unity .asset YAML 格式错误——`DynamicDifficultyConfigs:` 下的列表项必须使用**4空格缩进**。

```yaml
# ✅ 正确格式（Unity YAML 要求的缩进）：
    DynamicDifficultyConfigs:
    - StartDifficulty: 20        ← 4 空格
      ShuffleSplitCount: 5       ← 6 空格
      ShuffleSplitRatios: 1,1,1,10,1  ← 6 空格
      ShuffleOverflowFactor: 0.5      ← 6 空格

# ❌ 错误格式（Unity 无法解析，silent fallback → 无难度 → 100% WR）：
    DynamicDifficultyConfigs:
  - StartDifficulty: 20          ← 2 空格 ❌
    ShuffleSplitCount: 5         ← 4 空格 ❌
```

**修复**：重写 asset 文件中的 DynamicDifficultyConfigs 块，确保 `- StartDifficulty:` 前为 4 空格，属性行前为 6 空格。

**检测**：读取 asset 后检查配置数。用 `read_asset_combo` 如果返回 5 个以上配置，说明有残留旧格式。
```bash
grep -c "StartDifficulty" Assets/GameModule/GameMain/ConfigSo/Generated_enum/test/{level}.asset
# 应该输出 5，大于 5 说明格式有问题
```

### 现象 B：批跑长时间无输出（目录空 / 无 CSV）

**排查步骤**：
1. **检查 Unity 进程 CPU 时间**（判断是否卡死）：
   ```powershell
   powershell -Command "Get-Process Unity -ErrorAction SilentlyContinue | Select-Object Id, @{N='CPUmin';E={[math]::Round($_.TotalProcessorTime.TotalMinutes,1)}} | Format-Table -AutoSize"
   ```
   主 Unity Editor 进程（通常编号最小）CPU 时间持续增长 → 在运行。批跑子进程 CPU 时间 < 2 分钟 → 可能卡了。

2. **检查 Unity Editor 日志**（看批跑进度）：
   ```bash
   tail -30 ~/AppData/Local/Unity/Editor/Editor.log | grep "Bot Batch"
   ```
   正常输出：`[Bot Batch] Level L77 (11/21): 400 runs × 1 strategy = 400 games`
   如果长时间没有新进度输出 → batch 可能卡了。

3. **检查 auto-batch-request.json 是否被拾取**：
   ```bash
   ls -la BuildLogs/auto-batch-request.json
   # 文件不存在 = 已被 Unity 拾取
   # 文件存在 = Unity 还没处理，可能正在编译或 Editor 忙
   ```

4. **触发重编译后等一会再提交批次**：
   ```bash
   # 改 asset 文件后，Unity 需要 AssetDatabase.Refresh 才会加载新配置
   # 可以先 touch 一个脚本文件触发 recompile
   touch Assets/GameModule/Editor/Bot/BlastBotAutoBatchTrigger.cs
   # 等 15-30 秒编译完，再提交 auto-batch-request.json
   ```

### 现象 C：批次始终不跑

**排查**：
- Unity Editor 进程是否存在？（`Get-Process Unity`）
- Editor 是否在编译中？（`EditorApplication.isCompiling`）
- `_batchRunning` 标志是否被上一个卡住的批次锁死？
  （如果上一个批次异常退出，`finally { _batchRunning = false; }` 会重置，通常不会锁死）
- 重启 Unity Editor 是最后手段
