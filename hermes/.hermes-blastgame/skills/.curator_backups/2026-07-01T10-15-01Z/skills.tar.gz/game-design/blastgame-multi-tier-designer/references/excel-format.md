# 手动挑配置记录.xlsx 格式

## 列结构

| A（关号，合并5行） | B（难度，合并5行） | C（档位） | D（通关率） | E（SD） | F（SC） | G（Ratios） | H（溢出因子） |
|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|

- 每关 5 行（Tier1~Tier5）
- A、B 列按关号合并 5 行
- D 列通关率为小数（0.915 = 91.5%）
- 不允许 F 列（SC）之外的额外列，I~Z 列应全部为空

## 写入方式

```python
for row_idx in range(2, ws.max_row + 1):
    if ws.cell(row=row_idx, column=1).value and int(ws.cell(row=row_idx, column=1).value) == 66:
        vals = [91.5, 20, 5, '1,1,1,10,1', 0.5,  # T1
                91.5, 20, 5, '1,1,1,10,1', 0.5,  # T2
                62.0, 10, 4, '1,1,1,1', 0.5,     # T3
                51.0, 20, 5, '5,5,1,5,5', 0.5,   # T4
                51.0, 20, 5, '5,5,1,5,5', 0.5]   # T5
        for col, v in enumerate(vals, 2):  # 从 B 列开始写
            ws.cell(row=row_idx, column=col).value = v
        break
```

注意: 列索引从 1 开始。A=1, B=2, C=3...
enumerate(vals, 2) 从 B 列开始写，因为 A 列（关号）已存在。
vals 顺序: D(WR), E(SD), F(SC), G(Ratios), H(OF), 每档5值 × 5档 = 25值
