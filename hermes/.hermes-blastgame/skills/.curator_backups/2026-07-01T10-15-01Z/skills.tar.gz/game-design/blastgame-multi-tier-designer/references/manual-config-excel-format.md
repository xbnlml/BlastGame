# Excel 格式规范（手动挑配置记录.xlsx）

## 行格式
每关占用 **5 行**，每档一行：

| col1 | col2 | col3 | col4 | col5 | col6 | col7 | col8 |
|:----:|:----:|:----:|:----:|:----:|:----:|:----:|:----:|
| 66 normal | (空) | Tier1 | WR | SD | SC | Ratios | OF |
| (空) | (空) | Tier2 | WR | SD | SC | Ratios | OF |
| (空) | (空) | Tier3 | WR | SD | SC | Ratios | OF |
| (空) | (空) | Tier4 | WR | SD | SC | Ratios | OF |
| (空) | (空) | Tier5 | WR | SD | SC | Ratios | OF |

## 列说明
- col1: **关号 + 难度** 合并为一个字符串，空格分隔（如 "66 normal", "83 hard", "200 superhard"）
- col2: 始终为空（难度已合并到 col1）
- col3: "Tier1" ~ "Tier5"
- col4: WR（通关率，小数，如 0.915 = 91.5%）
- col5: SD（StartDifficulty）
- col6: SC（ShuffleSplitCount）
- col7: Ratios（ShuffleSplitRatios）
- col8: OF（ShuffleOverflowFactor）

## 难度标签
- normal: 无底色
- hard: 浅黄色底（FFFFEB9C）
- superhard: 粉红色底（FFFFC0CB）

## 注意事项
- 数据为 1-200 关连续排列，每关上方最好空一行
- WR 用小数（0.915 而非 91.5），直接写入不用乘以 100
