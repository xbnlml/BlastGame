# Extracting configs from campaign-attempts CSV

Bot 批跑结果的 `campaign-attempts-*.csv` 包含每局游戏的完整配置参数。

## CSV 列结构

```
LevelGroup,level,attemptIndex,seed,won,timeSec,endReason,replayRelativePath,
  startDifficulty,shuffleSplitCount,shuffleSplitRatios,shuffleOverflowFactor,
  DifficultyLevel,tier,isDynamicDiffcult,targetCellCount,clearedCellCount
```

| Col Index | Field | Description |
|:---------:|-------|-------------|
| 8 | startDifficulty | SD |
| 9 | shuffleSplitCount | SC |
| 10 | shuffleSplitRatios | Ratios |
| 11 | shuffleOverflowFactor | OF |

## 用法

```python
with open('campaign-attempts-L80-80-T1.csv') as f:
    reader = csv.reader(f)
    next(reader)  # skip header
    for row in reader:
        if int(row[1]) == 80:  # level 80
            sd = row[8]
            ratios = row[10]
            break
```

注意: 只有第一行就够——同一 batch 的所有局用相同的配置参数。

## 为什么要从 attempts CSV 反推

auto-batch-request.json 在 Unity 拾取后即删除，无法事后查阅。
但 attempts CSV 保留在 telemetry/bot/ 目录中，永久可查。
这让你可以从任何历史批次中恢复 exact 配置。
