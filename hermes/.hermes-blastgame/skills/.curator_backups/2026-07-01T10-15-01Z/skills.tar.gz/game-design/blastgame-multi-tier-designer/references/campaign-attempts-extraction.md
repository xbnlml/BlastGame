# campaign-attempts CSV 配置提取

## 列结构
| col | 字段 | 说明 |
|:---:|:----|------|
| 0 | LevelGroup | test |
| 1 | level | 关号 |
| 2 | attemptIndex | 尝试序号 |
| 3 | seed | 随机种子 |
| 4 | won | true/false |
| 5 | timeSec | 游戏用时 |
| 6 | endReason | 结束原因 |
| 7 | replayRelativePath | 回放路径 |
| **8** | **startDifficulty** | **SD 参数** |
| **9** | **shuffleSplitCount** | **SC 参数** |
| **10** | **shuffleSplitRatios** | **Ratios 参数** |
| **11** | **shuffleOverflowFactor** | **OF 参数** |

## 用途
在 telemetry/bot/ 目录下，campaign-attempts-*.csv 记录了每一局的 exact 动态难度参数。
读取第一行即可反推该批次运行时 asset 对应的配置。

## Python 读取示例
```python
import csv
with open('campaign-attempts-L80-80-T1.csv') as f:
    reader = csv.reader(f)
    next(reader)
    row = next(reader)
    sd = row[8]; sc = row[9]; ratios = row[10]; of = row[11]
```

## 注意
- 同一目录下的 summary CSV 对应同一配置
- 同一批次内所有局配置相同（取第一行即可）
