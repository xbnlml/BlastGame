# Optimizer Phase1 采样缺陷详解

## 发现来源
手动检查 L66 Phase1 raw CSV（80行 → 38 唯一配置），然后批量检查 51-75 全部 25 关，确认是系统性问题。

## 代码根因（BlastMultiTierPhase1AdaptiveSampler.cs）

### Round 1（16 个配置）
```csharp
internal static List<Phase1AdaptivePlan> BuildRound1Plans(MultiTierConfig config, int count) {
    var actualCount = Mathf.Clamp(count, 0, RatioPresets.Length);  // max 16
    for (var i = 0; i < actualCount; i++) {
        plans.Add(new Phase1AdaptivePlan {
            candidate = CreateFixedCandidate(config, RatioPresets[i], **Round1StartDifficulty=20**),
            //                               ↑ 全用 sd=20，只有 ratios 不同！
        });
    }
}
```

### Round 2（~47 个配置）
对每个 distinct tier target（T1=90%, T2=85%…），从 Round 1 结果挑最优代表，然后调 sd：
```csharp
var candidate = CreateFixedCandidate(config,
    representative.candidate.ratios,        // 用同一个 ratio
    Round1StartDifficulty + sdDirection * step * stepLevel  // 调 sd
);
```

当 T1 和 T2 都选到同一个 ratio 代表，T1 产生 sd={17,14,11}，T2 也产生 sd={17,14,11} → 完全相同的 (sd, ratios) → CSV 里的重复行。

### Round 3（剩余 ~16 个）
补漏，但 Round 1+2 已经产生了全部重复。

## 影响
- 名义 80 配置 → 实际有效探索 ~38（复用率 52%）
- 被浪费的是 200m 区间的采样机会（每局 ~5-10 秒 → 800 局 ≈ 1-2 小时）
- 完全可以通过去重避免：Round 2 计划完后 unique (sd, ratios) 再跑

## 对我方工作的影响
- Phase1/Phase2 数据宝贵，但不够——有效数据点只有 ~38/关
- 一轮探针（5 槽）就能产出 ~12.5% 的新数据点，效果显著
- 遇到 Phase1 数据不足不要死磕，直接跑探针
