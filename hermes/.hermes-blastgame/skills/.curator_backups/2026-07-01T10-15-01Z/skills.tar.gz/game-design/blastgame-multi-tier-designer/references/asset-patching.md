# Unity .asset YAML 格式说明（BlastGame）

## DynamicDifficultyConfigs 的正确格式

```yaml
    DynamicDifficultyConfigs:
    - StartDifficulty: 20        ← 4 空格
      ShuffleSplitCount: 5       ← 6 空格
      ShuffleSplitRatios: 1,1,1,10,1  ← 6 空格
      ShuffleOverflowFactor: 0.5      ← 6 空格
    - StartDifficulty: 26        ← 4 空格
      ...
```

### 错误后果

| 缩进 | 结果 |
|:----:|:----:|
| `- StartDifficulty:` 前 4 空格 ✅ | Unity 正常解析 |
| `- StartDifficulty:` 前 2 空格 ❌ | Unity 静默降级→默认配置→100% WR |

### 写入后验证

```bash
# 应输出 5 个 StartDifficulty
grep -c "StartDifficulty" Assets/GameModule/GameMain/ConfigSo/Generated_enum/test/{level}.asset
# >5 = 有残留旧数据，需要清理
```

### 通用替换方法

不要试图逐行替换。找到 `DynamicDifficultyConfigs:` 行和它之后的第一个 `customCellDrawingListV2:` 行，用新配置替换中间全部内容：

```python
text = open(path).read()
lines = text.split('\n')
dd_idx = lines.index(next(l for l in lines if 'DynamicDifficultyConfigs:' in l))
end_idx = lines.index(next(l for l in lines[dd_idx+1:] if 'customCellDrawingListV2:' in l), dd_idx+1)

new_block = ['    DynamicDifficultyConfigs:']
for c in combo:
    new_block.append(f'  - StartDifficulty: {c["sd"]}')
    new_block.append(f'    ShuffleSplitCount: {c["sc"]}')
    new_block.append(f'    ShuffleSplitRatios: {c["ratios"]}')
    new_block.append(f'    ShuffleOverflowFactor: {c["of"]}')

result = lines[:dd_idx] + new_block + lines[end_idx:]
open(path, 'w').write('\n'.join(result))
```

### 已知踩坑

- `patch_optimizer_config.py` 第一版写了 inline `{}` 格式 → Unity 不识别
- 第二版写了 2 空格 `-` → Unity 解析失败，100% WR
- 第三版用 line-based 替换但没找到正确的 end_idx → 留下 9 个配置（5 新的 + 4 旧的）
- **最终修复**：按 `customCellDrawingListV2:` 锚定块结束位置
