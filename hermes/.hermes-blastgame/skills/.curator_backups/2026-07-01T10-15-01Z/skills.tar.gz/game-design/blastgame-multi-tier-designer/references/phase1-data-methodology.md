# Phase1 数据挖掘方法论

## 核心原则

**优化器产出的不是"5个档位的配置"，而是一张 配置↔胜率 的对照表。**  
标签（T1~T5）只是搜索目标，不是配置的固定用途。

## 正确步骤

### 1. 读 Phase1 raw CSV
```python
import pandas as pd
p1 = pd.read_csv('phase1_raw.csv')
p1 = p1.rename(columns={
    'WinRate': 'wr', 'StartDifficulty': 'sd',
    'ShuffleSplitCount': 'sc', 'ShuffleSplitRatios': 'ratios',
    'ShuffleOverflowFactor': 'of', 'TotalRuns': 'runs'
})
p1['wr_pct'] = (p1['wr'] * 100).round(1)
p1['exp'] = (100 / p1['wr_pct']).round(2)  # 期望通关次数
```

### 2. 去重（同参数取 runs 最大的）
```python
p1 = p1.sort_values('runs', ascending=False)
p1 = p1.drop_duplicates(subset=['sd', 'sc', 'ratios', 'of'])
```

### 3. 检查与 summary/Phase2 的一致性
同一个 (sd,sc,ratios,of) 出现在多个阶段时：
- 如果 WR 不同 → 随机波动
- **以局数多的为准**
- 如果 Phase1 100局 标 62%，但 summary 400局 标 68%，那 68% 更可信

### 4. 自由组合搜索（核心！）

**不要被"这个配置标了T3所以只能当T3"限制。**  
从 Phase1 中按照实际胜率找三个梯队：

```python
t1_candidates = p1[p1['wr_pct'] >= 85]           # T1 梯队
t3_candidates = p1[(p1['wr_pct'] >= 55) & (p1['wr_pct'] <= 78)]  # T3 梯队
t5_candidates = p1[(p1['wr_pct'] >= 40) & (p1['wr_pct'] <= 66)]  # T5 梯队

for _, t1r in t1_candidates.iterrows():
    for _, t3r in t3_candidates.iterrows():
        for _, t5r in t5_candidates.iterrows():
            d13 = t1r['wr_pct'] - t3r['wr_pct']
            d35 = t3r['wr_pct'] - t5r['wr_pct']
            if d13 + d35 > 40: continue  # 总跨不超过40%
            g13 = round(t3r['exp'] - t1r['exp'], 2)
            g35 = round(t5r['exp'] - t3r['exp'], 2)
            if g13 < 0.30 or g35 < 0.20: continue  # 期望差门槛
            # ... 记录这个候选
```

### 5. Normal 关注意
- T1=T2 同配 → 搜索时 T1 配置自动复制到 T2
- T4=T5 同配 → 搜索时 T5 配置自动复制到 T4
- 实际只需要找 3 套配置，搜索空间小 10 倍

### 6. 验证
Phase1 的 WR 来自 80-100 局（精度约 ±10%）。  
选中的候选必须 patch 到 asset 后跑 Bot 400 局验证才算数。

## 常见误区

### ❌ 误区1：只在标了某档的数据里找
```
// 错误：只在标了 T3 的 Phase1 数据里找 T3 替代
phase2_picker.py --fix-tier T3 --target 65% 

// 正确：从所有 Phase1 数据里，找胜率在 65% 附近的任何配置
```

### ❌ 误区2：用百分比差额判断档差
```
// 错误：T3→T5 差 12%，够了
// 正确：期望 1.41→1.69 = +0.28，在 50-70% 区域太小
```

### ❌ 误区3：忽略总跨度
```
// 错误：T1-T3 和 T3-T5 各自都好，但 T1→T5 跨度 45%
// 问题：相邻档还好，但 T1 和 T5 差距太大 → 中间断档
// 上限：≤ 40%
```

### ❌ 误区4：不检查 Phase1 和 Summary 的一致性
```
// Phase1 标 wr=62%, but summary 标 wr=68%（同参数）
// 说明：Phase1 100局的精度不够，差距是波动
// 正确：以 summary（400局）为准
```
