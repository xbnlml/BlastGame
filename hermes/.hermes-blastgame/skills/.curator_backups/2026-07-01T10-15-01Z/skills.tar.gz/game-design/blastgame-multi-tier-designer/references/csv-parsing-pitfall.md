# CSV 解析坑：用 `csv` 模块，不能用 `cut`

## 现象
Bot 结果看起来全错了——如 T3=73.5% 读成 T3=17%。

## 根因
`campaign-summary-*.csv` 的格式：
```
LevelGroup,level,DifficultyLevel,failBucketDistribution,winCount,failCount,winkate
test,67,0,"0,0.028,0.009,0.17,0.208,...",294,106,0.735000
```

第 4 列 `failBucketDistribution` 是**引号括起来的逗号分隔列表**。`cut -d,` 不认引号，会把分布内的 `0.17` 当成 winkate。

## 修复
始终用 Python `csv.reader`。`winkate` 在第 7 列（`row[6]`）。

## 检测
如果读到异常的低 winkate，先用 python csv 模块重读确认。
