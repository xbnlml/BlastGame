# Presentation Format For User Reports

User has strongly expressed preferences. Follow these exactly.

## Level Status Summary

Use a markdown table with ALL 5 tiers and expected attempts:

```
L{关号} Normal 目标: 90/90/75/60/60

| 档位 | 胜率 | 期望次数 | 配置 |
|:----:|:----:|:--------:|------|
| T1=T2 | 88.5% | 1.13 | sd=22, sc=5, ratios=10,10,1,1,1 |
| T3 | 67.5% | 1.48 (+0.35) | sd=20, sc=5, ratios=10,1,10,1,10 |
| T4=T5 | 44.5% | 2.25 (+0.77) | sd=20, sc=5, ratios=1,10,10,10,1 |

| 档差 | 差值 | 体感 |
|:----:|:----:|:----:|
| T1→T3 | 21% | +0.35 次，有感觉 |
| T3→T5 | 23% | +0.77 次，明显 |
```

## Probe Results

```
| 槽位 | 配置 | Bot实测 | 期望 |
|:----:|------|:-------:|:----:|
| T1 | sd=4, all 1s | 85.5% | 1.17 |
| T2 | sd=22, 10,10,1,1,1 | 88.5% | 1.13 |
```

## Comparison Tables

When comparing two configs side by side:

```
| | 配置A | 配置B | 问题 |
|---|:-----:|:-----:|:----|
| T1 | 92% | 11.7% | — |
| T2 | 65% | 0.5% | — |
```

## DO NOT
- Use text descriptions like "T1=85%, T3=66%" without a table
- Use code blocks for data that should be a table
- Only show gaps without showing all 5 win rates
- Use `→` arrow notation as the primary display format
