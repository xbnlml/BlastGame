---
name: blastgame-bot-orchestrator
description: "BlastGame Bot 批跑 — 提交、监控(monitor_bot.py)、关弹窗"
category: game-design
---

# BlastGame Bot 批跑

> 被 `blastgame-level-optimizer` 在 Step 3/4/5 调用。

## 1. 提交

**工具：** `submit_batch.py`

```bash
python "~/AppData/Local/hermes/scripts/submit_batch.py" "89,90,91,95,99,100"
```

实现：patch 全部 asset → 聚焦 Unity → 等 30 秒 → 写一个 request（`levelSpec: "89,90,91"` 逗号分隔）→ 等消费 → 等全部 N 个新目录出现 → 输出结果。

### 手动提交步骤（备用）

1. patch asset（用 `patch`，不用 `write_file`）
2. 记录前状态（`auto-batch-last-export.txt` mtime + `telemetry/bot/` 已有目录列表）
3. 聚焦 Unity：`(New-Object -ComObject WScript.Shell).AppActivate("BlastGame")`
4. 等待 30 秒
5. 写 request.json
6. **消费验证：** 120s 未消费 → delete-recreate（删后等 3s 重写）→ 再等 120s。3 次 → 重启 Unity
7. **完成检测：** 前状态 mtime 变了或有新目录 → 读**最新目录**的 5 档，不混历史
8. **跑后验证：** 读 attempts CSV 第一行 startDifficulty 比对期望值

**不写 `__ForceReload.cs`，不写 `_ForceRefresh.cs`。**

## 2. request 生命周期

| 阶段 | request.json | result.json | 含义 |
|------|-------------|-------------|------|
| 提交后 | 存在 | 不存在 | 未拾取 |
| 运行中 | 存在(没删) | 不存在 | 正在跑 |
| 完成 | 不存在 | 存在 | 跑完了 |

**确认消费：** `ls BuildLogs/auto-batch-request.json`（不存在=已拾取）
**确认在跑：** `grep "Bot Batch" Editor.log | tail -1`

## 3. 运行后验证配置

Bot 跑完后，必须验证实际使用的配置是否与预期一致。从 campaign-attempts.csv 的第一行读 startDifficulty，比对是否等于你写进 asset 的 sd 值。不等则说明跑了旧配置，不计入轮次，修复 asset 后重跑。

## 4. 监控（完成检测）

**主方法（前台，推荐）：** `submit_batch.py` 内部实现。

1. 提交前记录 `auto-batch-last-export.txt` 的 mtime 和 `telemetry/bot/{lv}-{lv}-*` 的目录集合
2. 提交后每 3 秒检查：
   - mtime 变了 → 有新 export
   - 新目录出现（减去提交前集合）→ 有新批次完成
3. 只要**最新目录的 5 个 T1-T5 子目录齐全** → 判定完成
4. 不查历史目录，不混不同批次的数据

**双保险（备用）：** `monitor_bot.py`（后台监听 mtime）

```bash
terminal(background=true, notify_on_complete=true,
  command='python \"~/AppData/Local/hermes/scripts/monitor_bot.py\"')
```

每秒检测 `auto-batch-last-export.txt` mtime，变化时关弹窗+读结果+退出。

**多关合跑时（levelSpec="89,90,91"）：**
- mtime 在每关完成后都会变
- 新目录也会在每关完成后出现一个
- `submit_batch.py` 等 N 个新目录全部到齐才判定完成

**超时：** 每关最长等 5 分钟（`submit_batch.py` 内设超时）。超时后输出 TIMEOUT 并退出，留待中断恢复流程处理。

## 5. 弹窗行为（代码已修，待重编后生效）

修改了 Unity 端代码（`.cs` 变更，需 Unity 检测到变更并重编译后才生效）：

| 修改前 | 修改后 |
|--------|--------|
| 每档导出弹一次文件夹 | 每档不弹 |
| — | 整个批次完成时弹一次批次根目录 |

**代码位置：**
- `BlastWorkbenchWindow.Bot.cs` 行 ~491：`revealInFinder: false`（关掉每档弹窗）
- `BlastBotAutoBatchTrigger.cs` 行 ~140：`EditorUtility.RevealInFinder(batchRoot)`（批次结束弹一次根目录）

batchRoot = `telemetry/bot/{batch}/`（批次根目录，不是最后一档的子目录）。

## 6. CSV 读取

用 Python csv 模块，不用 `cut -d,`。
- `campaign-summary.csv`：winkate=胜率(0~1)，无配置参数
- `campaign-attempts.csv`：有 sd/sc/ratios/of

## 7. 排错

| 现象 | 排查 |
|------|------|
| 全部 100% WR | asset YAML 缩进错误 |
| 跑了旧配置 | patch asset 后没等 Unity 重载就写了 request |
| request 不消费 | 检查 Editor.log 有无 PollForRequest |
- `_isRunning` 锁死 | 修改 `.cs` 触发 domain reload 重置静态变量。代码已修（`window.Close()` 加 try-catch），正常情况下不会再发生，仅用户手动停 Bot 时可能触发 |
| monitor 未检测到跑完 | monitor 监听 `auto-batch-last-export.txt` mtime，但同目录多次提交时该文件 mtime 可能不变。改用 delete-recreate trick（删 request.json→等3s→重写）触发重新消费。另备自查：poll export 目录兜底 |
