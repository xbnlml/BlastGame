---
name: blastgame-auto-pipeline
description: "Orchestrator for BlastGame multi-tier tuning. Three-batch flow (批A/批B/批C) — not per-level loop. Full auto: Unity watchdog, crash recovery, batch progress."
version: 3.0.0
author: Hermes Agent
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [blastgame, game-design, orchestrator, pipeline]
    related_skills: [blastgame-level-optimizer, blastgame-multi-tier-designer, blastgame-bot-orchestrator]
---

# BlastGame 全自动多档位调优管道

> 编排器 — 不做单关决策。**批处理模式**：所有 pending 关同时过同一 Step，不走逐关循环。

## 依赖链

```
blastgame-auto-pipeline (编排器)
  ├── blastgame-level-optimizer (7步流程)
  │     ├── blastgame-multi-tier-designer (规则表)
  │     │     ├── references/probe-design.md (探针设计)
  │     │     └── references/judgment-rules.md (判定规则)
  │     └── blastgame-bot-orchestrator (批跑提交/监控)
  └── scripts/batch-runner.py (批B机械执行器)
```

## 三批流程

### 批A — Step 1+2（agent 驱动）

1. 读 progress.json，获取全部 pending 关
2. **⑦ 改关卡预判**（condition A: span<30pp, condition B: max<75%）
3. 命中 → 直接标记改关卡，排除
4. 未命中 → 设计 R1 探针（加载 probe-design.md）
5. 写入 progress.json

**中断恢复：** 从中断处继续当前批量，不丢进度。

### 批B — Step 3-5（terminal 机械循环）

调用 `scripts/batch-runner.py`，逐关：
1. patch asset → focus Unity → wait 30s → submit request
2. 等消费（180s 超时，聚焦重试 3 次 → 重启 Unity）
3. 等 export（10min 超时，Unity 崩溃则重启）
4. 记结果 → 下一关

**卡死处理：** 聚焦重试 3 次仍不消费 → 重启 Unity。Unity 崩溃 → 自动重启。不跳过任何关。

### 批C — Step 6+7（agent 驱动）

逐关加载 judgment-rules.md：
1. 最佳组合搜索（全枚举）
2. 过合格判定表、硬性违规、档差审美、品质线
3. 结果分级：✅合格 / ⚠️接近 / ❌远不合格 → 改关卡
4. 记录到 tuning-records（含全量数据池）
5. 更新 progress.json

**中断恢复：** 从 progress.json 继续，已判定的关跳过。

## 全自动保障机制

### Unity 进程守护

每次启动批B前检查 Unity 进程。不在则重启，等 60s 加载。

### 进度持久化

每关完成后写入 BuildLogs/pipeline-progress.json。恢复时读此文件继续。

## 参考文档

| 文档 | 内容 |
|------|------|
| `references/pipeline-watchdog.md` | 管道卡住诊断（含信号表、决策表、告警抑制规则、**批量目录命名格式**）。**注意：** watchdog 要求 `pipeline-progress-check.json` 包含 `stuck_count` 字段以抑制重复告警，缺少时按首次卡住处理 |
| `references/checkpoint-schema.md` | `pipeline-progress-check.json` 的必填字段定义 + 检查逻辑伪码 + 告警抑制规则实现 |
| `scripts/batch-runner.py` | 批B机械执行器 |
| `scripts/batch_b.py` | 批B前台版（分批执行，<10min/批不超时） |

## 已知坑

- **不写自治脚本替代 agent 决策。** 批B是纯机械循环（patch/submit/poll），批A/批C 必须由 agent 加载 skill 文件执行。
- asset 文件用 `patch` 修改，不用 `write_file` 覆盖。
- **白跑不记轮次。** 跑后读 attempts CSV 确认配置匹配。
- **批跑全部超时→改关卡死锁。** 当 batch-runner.log 显示全部关卡 `TIMEOUT → 改关卡` 且 `Done`/`改关卡`/`Remaining` 无余量时，管道进入"待决策"状态。不会自动生成下一批请求。看门狗应识别此模式并通知人工干预。详见 `references/pipeline-watchdog.md` 第 9 节。
- **`stuck_count` 未初始化导致重复投递（反复发生！）。** 如果 `pipeline-progress-check.json` 缺少 `stuck_count` 字段（或文件不存在），看门狗按首次卡住处理，每次 cron 触发都会投递完整报告，无法抑制重复告警。**注意：agent 天然易遗忘此字段**——因为 cron 任务的 prompt 只提到读 `levels_done`，没提写 `stuck_count`。**强化方案：** 写看门狗代码时，第一步就设 `stuck_count = 0` 并显式写入 checkpoint，之后再读旧值覆盖。详见 `references/pipeline-watchdog.md` 根因分析。新增 `stuck_count` 后首次写入会自动设 0，下次触发才会按抑制规则执行。详见 `references/checkpoint-schema.md`。
- **request 消费超时**
- **聚焦正确方法**：`subprocess.Popen` 而非 `subprocess.run`，避免 PowerShell 管道 hang。
- **AssetDatabase.Refresh 终极保险**：重启 Unity 后一切正常。文件监控死掉时这是唯一修复方式。
