# pipeline-progress-check.json Schema

> 监控 cron job 每次运行时读取/写入的 checkpoint 文件。
> 用于跨会话对比 `levels_done` 变化、抑制重复告警、检测 bot 目录活动性。

## 路径

```
BuildLogs/pipeline-progress-check.json
```

## Schema（必填）

```json
{
  "last_check": "2026-07-08 01:30",
  "levels_done": 15,
  "recent_bot_dirs": [
    "52-100-2026-07-08T01-22-00"
  ],
  "latest_bot_timestamp": "2026-07-08T01:22",
  "last_progress_update": "2026-07-07 11:43",
  "stuck_count": 0,
  "last_stuck_alert": null
}
```

| 字段 | 类型 | 要求 | 用途 |
|------|------|------|------|
| `last_check` | string | `YYYY-MM-DD HH:MM` 格式 | 本次检查时间 |
| `levels_done` | int | ≥ 0 | 上次读取的 `pipeline-progress.json` 的 `levels_done` 值 |
| `recent_bot_dirs` | string[] | 可空，有活动时应有 1+ 条 | 最近 30 分钟内出现的新 bot 目录完整路径列表 |
| `latest_bot_timestamp` | string | ISO 格式或 `HH:MM` | 最新 bot 目录的时间戳 |
| `last_progress_update` | string | ISO 格式 | `pipeline-progress.json` 文件的 mtime |
| `stuck_count` | int | **必需，初始 0** | 连续卡住检测计数。用于看门狗告警抑制：0=未卡住, 1=首次, 2=第二次, 3+=[SILENT] |
| `last_stuck_alert` | string\|null | ISO 格式或 null | 上次投递卡住告警的时间。null=从未投递过 |
| `done_array_count` | int | **可选**，推荐 | `pipeline-progress.json` 中 `done` 数组的实际长度。用于自检：与 `levels_done` 不一致说明 JSON 数据受损或手动修改过 |
| `stuck` | bool | **可选** | 本次检查的卡住判定结果。方便快速读取，不用重新计算 |
| `stuck_reason` | string | **可选** | 卡住原因的文字描述，供人工审查。每次检查都应更新为最新原因 |

> **⚠️ 常见错误：忘记 `stuck_count`。** Cron watchdog 实现中容易忽略此字段（如 2026-07-08 04:51 的检查就漏写了）。缺失此字段会导致下次检查无法识别上一轮是否已告警，从而绕过告警抑制规则，每次 cron 都投递完整报告。**修复方法：** 发现缺失时，看门狗应设 `stuck_count = 0` 初始化，并返回中说明首次进入抑制循环。

## 检查逻辑伪码

```python
# 读取
prev = read checkpoint  # may be None
curr = json.load(open('BuildLogs/pipeline-progress.json'))

# 交叉验证 levels_done vs done 数组长度
assert curr['levels_done'] == len(curr['levels']['done']), \
    f"levels_done {curr['levels_done']} != done array len {len(curr['levels']['done'])}"

# 精确时间窗检查（-newermt 而非 -mmin -30，避免滑窗效应）
last_check_time = prev.get('last_check', None) if prev else None
if last_check_time:
    # 将 "2026-07-08 13:26" 转为 ISO 格式
    from datetime import datetime
    anchor = datetime.strptime(last_check_time, '%Y-%m-%d %H:%M').strftime('%Y-%m-%d %H:%M:%S')
    cmd = f'find telemetry/bot/ -newermt "{anchor}" -type d 2>/dev/null'
else:
    # 无前次记录时用常规 -mmin -30
    cmd = 'find telemetry/bot/ -mmin -30 -type d 2>/dev/null'
bots = subprocess.check_output(cmd, shell=True).decode().strip().splitlines()

# 也检查当天活动（Burst 检测）
today_cmd = f'find telemetry/bot/ -newermt "{date.today().isoformat()}" -type d 2>/dev/null'
today_bots = subprocess.check_output(today_cmd, shell=True).decode().strip().splitlines()

# 交叉验证记录
done_array_actual = len(curr['levels']['done'])
```

if curr.levels_done > prev.levels_done OR bots changed:
    # 有推进
    prev.stuck_count = 0
    输出正常/恢复报告
elif prev.stuck_count == 0:
    prev.stuck_count = 1
    输出首次卡住告警（🔴 完整报告）
elif prev.stuck_count == 1:
    prev.stuck_count = 2
    输出第二次卡住告警（⚠️ 简要升级报告）
else:
    prev.stuck_count += 1
    [SILENT]  # 抑制重复投递

prev.last_check = now
prev.recent_bot_dirs = bots
prev.latest_bot_timestamp = bots[0] or "无"
prev.last_progress_update = curr_file_mtime
write checkpoint
```

## 首次运行

`pipeline-progress-check.json` 不存在时，无法做 delta 比较。
此时按 **stuck_count = 0** 处理（输出完整报告，不做卡住判定）。
写入首次 checkpoint 供下次对比。
