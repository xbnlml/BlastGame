# Pipeline 看门狗 — 管道卡住诊断与告警

> **⚠️ 每次写入 checkpoint 前必查：`stuck_count` 字段是否存在。** 如果 `pipeline-progress-check.json` 缺少 `stuck_count`（或文件是新建的），设 `stuck_count = 0` 再写入。
> 这是 checkpoing schema 的硬要求，也是告警抑制的根基。2026-07-08 多次 cron 检查仍漏写此字段，导致每次投递完整报告。
> 详见 `references/checkpoint-schema.md`「常见错误: 忘记 stuck_count」。

> 自动检测调优管道是否卡住，卡住时通过 cron job deliver 通知用户。
> 本文件记录所有诊断信号、检查步骤和状态判定规则。

## 诊断信号总览

管道"卡住"不是单一症状，以下信号各有权重：

| 信号 | 优先级 | 含义 |
|------|--------|------|
| `levels_done` 连续两次无变化 | 🔴 高 | 进度未推进（需配合其他信号确认）|
| 同关卡反复跑（bot 目录 level 前缀不变） | 🔴 高 | 管道在同一个关卡空转（agent 未推进到下一关）|
| 最近 30 分钟无新 bot 目录 | 🔴 高 | agent 可能卡在了某个步骤上 |
| **新 bot 目录存在但为空（无 T1-T5 子目录）** | 🟢 低 | Unity 刚创建批次根目录，尚未开始写入 tier 数据。这是 **准备信号**，不是卡住 |
| `auto-batch-request.json` 不存在 | 🔴 高 | agent 未提交新关或提交后已消费 |
| **`auto-batch-request.json` 存在 + Unity 日志显示正在跑旧批次** | 🟡 中 | **批次排队中** — Unity 正在处理一个长批次（如 49 关），新请求等待当前批次完成后才消费。不是卡住，但需确认旧批次仍有活动 |
| Unity 进程存在但长期无活动 | 🟡 中 | 需确认 Unity 是在等待还是在排查 |
| `pipeline-progress.json` 修改时间远早于最后批次 | 🟡 中 | 进度文件未同步 → 需综合判断 |
| **`levels_done` 14h 不变 + 持续有新 bot 目录 + Unity 日志活跃** | 🟡 中 | **数据收集模式** — Unity 正在跑一个大批次（如 49 关全部），`levels_done` 只反映已晋级关卡数，不反映批次活动。以 Unity 日志 mtime 为实时信号 |
| **`monitor_bot.py` 存在但监控的目录路径已过期** | 🟡 中 | monitor 启动时指定了一个旧 batch 目录，Unity 可能已开始新批次写入其他目录。检测方法：查 monitor 命令行中的 batch_dir 路径 vs 最新 bot 目录 |
| Unity.ILPP.Runner.exe 存在 | 🟢 低 | IL2CPP 正在构建 — 这是 _活跃_ 信号 |

---

## 详细检查步骤

### 1. 基础数据 — pipeline-progress.json（含 mtime 信号）

**路径**: `BuildLogs/pipeline-progress.json`

```json
{
  "scope": "51-100",
  "levels_total": 50,
  "levels_done": 9,
  "levels": { ... }
}
```

**注意**: `levels_done` 可能 **滞后于实际批次活动**。如上次会话所示，该文件最后修改于 7月4日，但第 55 关的批次于 7月6 日仍成功运行。说明驱动脚本可能不再更新该 JSON，但 Unity Editor 仍在处理请求。

**📌 关键信号：`pipeline-progress.json` 的 mtime 是"最后 ingestion 时间"**，比 `levels_done` 数值更可靠。即使 `levels_done` 没变，mtime 更新了也说明有脚本在写进度——这是活性信号。反之，如果 mtime 远早于最新 bot 目录时间（如 30h vs 3h），说明 ingestion 链已断裂，是管道的根本问题。

**检查命令**:
```bash
# 读取 levels_done
cat /c/Users/Administrator/Documents/BlastGame/BuildLogs/pipeline-progress.json | grep levels_done
# 查看文件修改时间（= 最后 ingestion 时间）
stat -c '%y' /c/Users/Administrator/Documents/BlastGame/BuildLogs/pipeline-progress.json
```

### 2. 批跑输出目录 — telemetry/bot/

**路径**: `telemetry/bot/`

目录命名格式: `{level}-{level}-{timestamp}`, `{level1_level2}-{timestamp}`, 或 **批量格式** `L{level_list}-T{N}-{timestamp}-batch-range`

> **批量格式（2026-07-08 新观察）**: `L51_55_57_61-65_70_76-78_80-81_83-85_87-88_91_94-95_97_99-100-T5-2026-07-08T15-03-05.037-batch-range`
> 特征：L 前缀 + 逗号/范围混合列表 + T{1-5} 标记 tier + 时间戳 + `-batch-range` 后缀。这是全自动调优管道提交大批次（26+ 关 × 5 档）时的新命名约定。
> 一个完整批次会生成 5 个这样的目录（T1–T5 各一个），每个约 22-25 分钟间隔。
> **扫描注意**：`find`/`ls` 直接扫根目录即可，不需要匹配前缀模式。

**检查命令**:
```bash
# 列出最近 bot 目录（按时间排序）
ls -lt /c/Users/Administrator/Documents/BlastGame/telemetry/bot/ | head -5
# 查看最新目录的修改时间
stat -c '%y' "/c/Users/Administrator/Documents/BlastGame/telemetry/bot/$(ls -t /c/Users/Administrator/Documents/BlastGame/telemetry/bot/ | head -1)"
```

**判定**: 最近 30 分钟内有新目录 → 管道在正常运行。否则标记为"无活动"。

**精确时间窗检查（`find -newermt` 替代 `-mmin`）**：

当看门狗在固定间隔运行（如每 15/30 分钟 cron）时，需精确判断"从上次检查至今"是否有新活动，而非笼统的 `-mmin -30`。

```bash
# 精确：检查从 last_check 时间点至今的文件活动
find "telemetry/bot/" -newermt "2026-07-08 12:56" -type d 2>/dev/null | head -5

# 配合 stat 验证实际时间
stat -c '%y %n' "telemetry/bot/$(ls -t telemetry/bot/ | head -1)"
```

**优势**: 避免 `-mmin` 的滑窗效应——如果 cron 在 T+25min 运行，`-mmin -30` 会漏掉 T 时刻前后边界的数据，而 `-newermt` 以检查时间为锚点精确截断。

#### Bot 目录内容验证（超越目录存在性检查）

有时 Bot 目录虽然存在，但其内部可能为空（批次刚创建根目录，尚未写入 CSV 数据）。更可靠的活力信号是**确认目录内有实际数据文件**。

```bash
# 检查最新 bot 目录是否包含真实 CSV 文件
find "telemetry/bot/$(ls -t telemetry/bot/ | head -1)" -name "*.csv" | head -5
# 有输出 = 有真实数据；无输出 = 空目录或刚创建

# 更彻底的检查：确认 T1-T5 各 tier 都有数据
find "telemetry/bot/$(ls -t telemetry/bot/ | head -1)" -name "*T*.csv"
# 预期输出 10+ 行（每 tier 有 ca- 和 cs- 两个 csv）
```

**实例（2026-07-08 13:26）**：`51_55-2026-07-08T12-39-10` 目录下有 `L51_55-T1-.../ca-L51_55-T1.csv`、`cs-L51_55-T1.csv` 等共 6 个 CSV 文件，说明该批次确实产出了数据。

**判定影响**：
- 目录存在 + 有 CSV → ✅ 真实批次活动
- 目录存在 + 无 CSV → 🟡 刚刚开始或目录创建中断
- 目录不存在 → ❌ 无活动

#### 特例：父目录 mtime 单独更新（子目录缺失）

**现象**: `auto-batch-result.json` 的 `outDir` 路径所指向的 bot 子目录**不存在于文件系统中**，但 `bot/` 父目录的 mtime 在相应时刻有变化。

**2026-07-07 实例**: L90 批次在 11:19 完成（`auto-batch-result.json` 的 `finishedUtc` 确认），bot 父目录 mtime 为 `11:19:57`，但 `90-90-2026-07-07T11-19-33` 子目录不存在，`ls -lt bot/` 未显示该目录。

**可能原因**:
- Unity auto-batch-trigger 内部写入 result.json 但 export 目录因某些原因（如弹窗被拦截、路径权限问题）未持久化
- 批次在 Unity 内完成但写出中途被中断（关闭弹窗、重编译等）
- `auto-batch-last-export.txt` 指向的路径与 bot/ 子目录命名不完全一致

**检查方法**:
```bash
# 确认子目录是否存在
ls -la "/c/.../telemetry/bot/" | grep "90-90.*11-19"
# 查看 bot/ 父目录 mtime（作替补信号）
stat -c '%y' "/c/.../telemetry/bot/"
# 比对 auto-batch-result.json 的 outDir 路径
cat BuildLogs/auto-batch-result.json | grep outDir
```

**判定影响**: 当 `auto-batch-result.json` 报告成功但子目录缺失时，管道可能比预期的更卡——因为上次 \"成功\" 的批次可能只有元数据写入而没有实际跑出数据。看门狗应仍视为无活动（不计为进展），同时标记"最后批次可能未产生数据"。

### 3. Unity 进程健康检查

**检查命令** (Windows/MSYS2):
```bash
tasklist | grep -iE '(Unity|mono|il2cpp|batch)'
```

**关键进程解读**:

| 进程 | 含义 |
|------|------|
| `Unity.exe` | Editor 主进程 — 可能空闲也在 |
| `Unity.ILPP.Runner.exe` | **IL2CPP 构建中** — 这是活跃信号，说明在打包 |
| `UnityShaderCompiler.exe` | 着色器编译 — 背景活动 |
| `UnityPackageManager.exe` | 包管理器 |
| `Unity.Licensing.Client.exe` | 许可证验证 |
| `UnityAutoQuitter.exe` | 空闲超时退出器 |

**Unity 空闲判定**: 仅有 `Unity.exe` + `Unity.Licensing.Client.exe` + `UnityShaderCompiler.exe` + `UnityPackageManager.exe` 而无 `Unity.ILPP.Runner.exe`，且无 `monitor_bot.py` 对应进程 → Unity 很可能处于空闲等待状态。

### 4. 自动批跑触发器状态

**工作原理** (`BlastBotAutoBatchTrigger.cs`):
- 每 5 秒轮询 `BuildLogs/auto-batch-request.json` 是否存在且 mtime 更新
- 检测到新请求 → 执行批跑 → 写入 `auto-batch-result.json` → **删除** `auto-batch-request.json`
- 重复上述循环

**关键文件**:
```bash
# auto-batch-request.json — 存在 = 有未消费的请求（或正在跑）
#   （运行期间不会删除：RunBot → WriteResult → TryDelete）
# auto-batch-result.json — 存在 = 最后完成的批次结果
# auto-batch-last-export.txt — 最后导出路径
```

**检查命令**:
```bash
# request.json 不存在 = Unity 在空闲等待
ls -la BuildLogs/auto-batch-request.json       # 应不存在（已消费）
cat BuildLogs/auto-batch-result.json            # 查看最后批次结果
cat BuildLogs/auto-batch-last-export.txt        # 最后输出路径
```

**判定**: `auto-batch-request.json` 不存在 + `auto-batch-result.json` 显示成功 + 超过 30 分钟无新 bot 目录 → **管道卡住，Unity 空闲等待中**。

### 5. Unity 日志分析

**主日志路径**: `BuildLogs/unity-launch-test.log`（注意数字后缀，如 `unity-launch-test3.log` 可能是正在写入的活跃日志——选最新的 `.log` 文件）

**查看最后操作**:
```bash
tail -30 BuildLogs/unity-launch-test.log
```

**关键日志信号**:

- `"[Bot Batch] Level L(\d+) \((\d+)/49\)"` — **当前批次进度**。如 `L64 (12/49)` 表示第 12/49 关正在跑。这是最可靠的实时活动信号
- `"[Bot Batch Jenkins] 完成，最后导出目录: ..."` — 批次完成标记
- `"BlastBotAutoBatchTrigger:PollForRequest"` — 触发器在轮询（正常活动）
- `"Successfully resolved entitlement details"` — 许可证续签（背景活动）
- `"[Licensing"` — 许可证相关，不表示管道推进
- `"[Bot Batch"` (无 Level 号) — 可能是 **monitor_bot.py 检测到 export 时的日志**，不是实际批次。确认方法：检查 `auto-batch-result.json` 的 `finishedUtc` 是否为空或过期

**实时活动性判定：** 日志 mtime + tail 提取当前关卡，是比仅检查 Unity 进程存在更精细的信号。Unity 可能活着但卡在某个状态，日志的 mtime 和最后几行会暴露。

```bash
# 1. 选最新的 unity log 文件
LATEST=$(ls -t BuildLogs/unity-launch-test*.log 2>/dev/null | head -1)
# 2. 检查 mtime（活动性）
stat -c '%y' "$LATEST"
# 3. tail 提取当前跑的关卡
#    行如: [Bot Batch] Level L64 (12/49): 400 runs x 1 strategy = 400 games
tail -20 "$LATEST" | grep -oP 'Level L\K\d+ \(\d+/\d+\)' | tail -1
```

**判定规则：**
- mtime < 5 分钟前 + 能提取到 `Level L\d+` 行 → **Unity 正在活跃处理批次**
- mtime < 5 分钟前 + 无 `Level L\d+` 但有 `PollForRequest` 行 → Unity 在轮询等待下一请求
- mtime > 30 分钟前 → **Unity 可能卡住或已空闲**，需综合其他信号

**查看 Unity 启动时间**:
```bash
head -10 BuildLogs/unity-launch-test.log | grep "Date:"
```

### 6. 外部驱动进程检查

管道需要外部脚本写入 `auto-batch-request.json` 来推进。检查是否有此类进程：

```bash
tasklist | grep -iE '(python|cmd|powershell|jenkins|batch)'
```

**无匹配 = 外部驱动已停止**。Unity 虽然活着但等不到新请求。

如果看到 Python 进程，进一步确认是否与管道相关（Hermes 后台进程也会显示为 python.exe）：
```bash
wmic path win32_process where "name='python.exe'" get ProcessId,CommandLine
```

### 7. 管道进度快照检查

**文件**: `BuildLogs/pipeline-progress-check.json`

作用：记录上次检查时的快照，用于跨会话对比 `levels_done` 变化。

```json
{
  "last_check": "2026-07-08 01:30",
  "levels_done": 15,
  "recent_bot_dirs": ["52-100-2026-07-08T01-22-00"],
  "latest_bot_timestamp": "2026-07-08T01:22",
  "last_progress_update": "2026-07-07 11:43",
  "stuck_count": 0,
  "last_stuck_alert": null
}
```

**必填字段说明：**

| 字段 | 类型 | 用途 |
|------|------|------|
| `last_check` | string | 本次检查时间，格式 `YYYY-MM-DD HH:MM` |
| `levels_done` | int | 上次读取的 `levels_done` 值，用于 delta 比较 |
| `recent_bot_dirs` | string[] | 上次看到的最近 bot 目录列表（用于检测目录是否新增） |
| `latest_bot_timestamp` | string | 上次检查时最新 bot 目录的时间戳 |
| `last_progress_update` | string | `pipeline-progress.json` 的 mtime |
| `stuck_count` | int | **必需。** 累计连续卡住检测次数。用于告警抑制（见 `看门狗投递策略` 节）。初始 0，状态变化时 reset 为 0 |
| `last_stuck_alert` | string\|null | 上次投递卡住告警的时间。用于判断是否该升级/静默 |

**检查逻辑：**
1. 读取此文件的各字段作为**上次状态**
2. 读取当前 `pipeline-progress.json` 的 `levels_done`，比对
3. 检查 `telemetry/bot/` 最近 30 分钟新目录列表，与 `recent_bot_dirs` 对比
4. 如果 `levels_done` 未变 且 无新增 bot 目录 → `stuck_count++`
5. 如果 `levels_done` 变了 或 有新 bot 目录 → `stuck_count = 0`（恢复）
6. 更新 `pipeline-progress-check.json` 写入当前快照

---

### 8. 同关卡空转检测

**信号**: 连续两次检查发现 bot 目录的 level 前缀（如 `55-55-`）完全相同，且 `levels_done` 未增长。

```bash
# 检查两次检查间 bot 目录的 level 是否变化
# 比较 recent_bot_dirs 中的目录名前缀
```

**根因**: agent 卡住或会话中断后重启，未正确推进到下一关。恢复方法：手动检查 progress.json → 取当前 pending 关 → 提交至下一关。

**判定**: 如果连续 3 次以上检查发现 bot 目录前缀未变 → 管道在**空转**，需外部干预提交下一关请求。

### 9. 批次成功完成但无后续请求（Post-Batch Stall）

**信号：**
- `auto-batch-request.json` **不存在**（已被消费，但无新请求生成）
- `auto-batch-result.json` 存在且显示 `success: true` + 最近 `finishedUtc`
- 最近 Bot 目录的 **T1–T5 全部齐全**（批次完整完成）
- `levels_done` 多轮未变
- 最近 30 分钟无新 Bot 目录
- `pipeline-progress.json` 长时间未更新（即使批次已完成）
- `multi-tier-opt/` 长时间无更新（无结果处理）

### 实例 A（2026-07-08 16:16 — Unity 已退出的 Post-Batch Stall）

**情景：** 管道当天从 13:30 到 15:03 连续跑了 T1→T5 完整 5 档（每档 26 关），之后完全停摆。

| 信号 | 值 |
|------|-----|
| `levels_done` | 15（自 07-07 10:13 起 ~30 小时未变） |
| 最新 bot 目录 | `...-T5-...` 于 **15:03**（73 分钟前） |
| 30 分钟内新 bot 目录 | ❌ 无 |
| Unity 进程 | ❌ 已退出 |
| Python 管道脚本 | ❌ 无 |
| `pipeline-progress.json` mtime | 07-07 11:43（~28.5 小时未变） |
| `auto-batch-request.json` | 不存在 |

**诊断：** 🔴 **Post-Batch Stall**（见 §9）。批次完整产出（T1–T5 全部 CSV 齐全），但外部驱动未提交下一批请求。当日上午各级别的 T1→T5 目录间隔约 22-25 分钟，说明 Unity 工作节奏稳定，问题在驱动链。手动恢复方法见 §9「恢复步骤」。

### 实例 B（2026-07-08 18:06 — Unity 仍在运行的 Post-Batch Stall）

**情景：** 同一批 T1→T5 批次当天下午跑完（15:03），但到 18:06 仍无后续活动。与实例 A 的区别是 Unity Editor **并未退出**。

| 信号 | 值 |
|------|-----|
| `levels_done` | 15（自 07-07 ~31 小时未变） |
| 最新 bot 目录 | `...-T5-...` 于 **15:03**（3h+ 前） |
| 30 分钟内新 bot 目录 | ❌ 无 |
| **Unity 进程** | ✅ **仍在运行**（PID 71260，已启动 ~16.5h，含 Unity.ILPP.Runner 等子进程） |
| Python 管道脚本 | ❌ 无（仅 Hermes 后台 pythonw.exe） |
| `pipeline-progress.json` mtime | 07-07 11:43（~30 小时未变） |
| `auto-batch-request.json` | 不存在 |
| 当日 bot 活动 | 13:30~15:03 T1→T5 完整 5 轮（约 22-25min 间隔）|

**关键区别：** Unity 仍然活着，但处于**空闲等待**状态——没有新 request.json 给它消费。Unity 启动已超 16 小时，说明不是刚重启的意外停摆，而是驱动链断开了几个小时后的持续空闲。

**诊断：** 🔴 **Post-Batch Stall（Unity 空闲变体）**。Unity 活得好好的（有 UnityPackageManager、ILPP 进程），但没有 request 可消费。最迷惑人的是：初学者可能认为 Unity 进程在就等于管道在运行，其实 Unity 只是在空等。

**📌 判定提示：** 如果只看 Unity 进程存在性，本例会被误判为 🟢 正常运行。必须穿透 Unity 活着的假象：
1. **`auto-batch-request.json` 不存在** → 没有可消费的请求
2. **`pipeline-progress.json` mtime 与最新 bot 目录的时间差** → 本例差 ~27h，说明 ingestion 已断裂
3. **最新 bot 目录的时间** → 3h+ 前，说明不是批次间正常间隙
4. **当日 bot 活动模式** → 前一次爆发是连续的 5 轮（T1→T5 每 22-25min），之后突然静默 3h+，远超爆发间歇（正常 40-60min），符合 Stall

**恢复步骤：** 与 §9 相同。

---

### 实例（2026-07-08 早上 — 通宵批次 Post-Batch Stall）：
- `levels_done` 停留在 **15**（>18 小时未变）
- `pipeline-progress.json` 最后修改 **07/07 11:43**（>17 小时）
- `auto-batch-request.json` 不存在（已消费，未生成新请求）
- 自 T5 完成后 **56 分钟无任何活动**

**根因链条：**
```
外部驱动（agent/脚本）提交 request
  → Unity PollForRequest 拾取并执行批次
  → T1→T2→T3→T4→T5 全部完成 ✅
  → auto-batch-request.json 被删除（消费完毕）
  → 等待外部驱动提交下一请求
  → ❌ 外部驱动未运行 / 会话中断 / 脚本未触发
  → 管道永久停留在"等待下一请求"状态
```

> **⚠️ stuck_count 陷阱: 本次会话（2026-07-08 16:16）的看门狗检查仍漏写了 `stuck_count` 字段。** 此前 checkpoint 已有 `last_check`, `levels_done`, `recent_bot_dirs`, `latest_bot_timestamp`, `last_progress_update` 五个字段，唯独缺 `stuck_count`——与新生成的检查点完全一致。说明看门狗 agent 每次重新构造 JSON 时天然遗忘此字段。
> **根因：** agent 的 cron 实现从任务描述中得知 `levels_done` 是必读字段，但未被告知 `stuck_count` 也是必写字段。由于该字段不在 JSON 示例中显式展示（watchdog doc 的示例在 §7，但 agent 可能不读全文），每次都掉坑。
> **修复：** 看门狗必须在首次写入 checkpoint 时就包含 `stuck_count: 0`。参见 `references/checkpoint-schema.md` 完整 schema 和本文件 §「看门狗投递策略」的检查逻辑。

**特征：** 区别于 Section 10 的"全部超时"模式，此模式中 **批次本身运行成功**，问题在于驱动链断开。

**识别方法：**

```bash
# 1. 确认最后批次是否完整完成
ls -la "/c/Users/Administrator/Documents/BlastGame/telemetry/bot/$(ls -t /c/Users/Administrator/Documents/BlastGame/telemetry/bot/ | head -1)/"
# 应有 5 个子目录 L*-T1-* ... L*-T5-*，全部齐全

# 2. 确认 result.json 状态
cat /c/Users/Administrator/Documents/BlastGame/BuildLogs/auto-batch-result.json 2>/dev/null
# 应有 success: true + finishedUtc

# 3. 确认 pipeline-progress.json 未对应更新
cat /c/Users/Administrator/Documents/BlastGame/BuildLogs/pipeline-progress.json | grep levels_done

# 4. 检查外部驱动是否存在（Python Hermes 后台进程仍监听？）
tasklist | grep -i python
```

**判定影响：**
- `levels_done` 未更新 + Bot 批次完整完成 = **数据已就绪但未消费**
- 这不是 Unity 端的问题，而是 **外部驱动/Agent 端断连**
- 管道需要 **人工恢复驱动**：读取最新 Bot 数据 → 更新 levels_done → 提交下一批请求

**恢复步骤：**
1. 读取最新 Bot 目录的 campaign-attempts.csv 获取各 Tier 配置和 WR 数据
2. 在 `tuning-records.md` 记录结果（如果该批次是针对改关卡/待确认关的重测）
3. 手动更新 `pipeline-progress.json`：将新完成的关卡加入 `done` 数组，递增 `levels_done`，从 `pending` 数组移除
4. 提交下一批请求（写 `auto-batch-request.json`），或结束本范围

---

### 10. 批跑全部超时→改关卡，无下一批请求

**信号**：
- `auto-batch-request.json` 不存在
- `auto-batch-result.json` 存在且显示上一批已完成
- `batch-runner.log` 显示全部关卡均 `TIMEOUT → 改关卡`
- `levels_done` 多轮未变
- 最近 30 分钟无新 bot 目录
- `monitor_bot.py` 进程可能存活但处于 `S (sleeping)` 状态（非 `R (running)`）

**识别方法**:

```bash
# 1. 读 batch-runner.log 确认最后一批状态
cat BuildLogs/batch-runner.log
# 输出示例:
#   [N/6] LX → TIMEOUT → 改关卡
#   === BATCH COMPLETE ===
#   Done: 15  改关卡: 44   Remaining: 0

# 2. 检查 monitor_bot.py 进程状态
cat /proc/<pid>/status | grep State
# 示例输出: State:  S (sleeping)   ← 活着但空闲
# 正常应有活动时: State:  R (running)

# 3. 确认是否为新状态而非旧监控残留
ls -la BuildLogs/auto-batch-request.json    # 应不存在
cat BuildLogs/auto-batch-result.json         # 应有 success: true 和最近的 finishedUtc
```

**根因**: 最后一批次的所有关卡都因超时被标记为"改关卡"（需人工重调），但 pipeline 未能自动生成下一批请求。pipeline 处于"待决策"状态——所有 pending 关已处理，下一关序列为空，需外部决定是继续调已标记的改关卡还是结束本范围。

**判定**: 连续两次检查均满足以上条件 → **管道卡住，pipeline 处于"改关卡死锁"状态**。需人工检查改关卡列表并决定下一步行动（继续重调或关闭范围）。

### 11. Burst Activity Pattern — 间歇性活动检测

**现象**: 管道在短时间内（5-15 分钟）集中产出多个 bot 目录（一批），然后进入 40-60 分钟的空闲期，之后可能再爆发下一批。这种"爆发-空闲"节奏可能重复多次。

**实例（2026-07-08）**:
- 12:32–12:42 (10min): 产出 `61-61-...` 和 `51_55-...` 两个 bot 目录，各带 T1/T3/T5 CSV 数据
- 12:42–13:26 (44min): 无新活动
- 看门狗在 13:26 运行时，严格 30 分钟窗口内无新目录，但实际当天有 2 次真实批次产出

**根因推测**:
- 外部驱动脚本（batch-runner.py / orchestrator）按关提交后进入等待状态，待 Unity 跑完该关再提交下一关
- Unity 跑一关（含 3–5 个 tier）需要 5–15 分钟
- 驱动脚本提交完一批后自身退出或休眠，等待下一次 cron/定时器触发
- 这是**正常工作流**，不是卡住——只是节奏慢

**识别方法**:

```bash
# 1. 查看当天全部 bot 目录，不限于 30 分钟窗口
ls -lt telemetry/bot/ | grep "$(date +%Y-%m-%d)" | head -20

# 2. 查看目录内容验证确为数据产出
for d in $(ls -t telemetry/bot/ | grep "$(date +%Y-%m-%d)" | head -5); do
    csv_count=$(find "telemetry/bot/$d" -name "*.csv" 2>/dev/null | wc -l)
    echo "$d → $csv_count csv files"
done

# 3. 检查 pipeline-progress.json mtime（即使 levels_done 未变，mtime 可能已变）
stat -c '%y' BuildLogs/pipeline-progress.json

# 4. 查看 auto-batch-request.json — 存在 = 有等待消费的请求
ls -la BuildLogs/auto-batch-request.json 2>/dev/null && echo "EXISTS (pending)" || echo "NOT EXISTS (idle/idle-burst)"
```

**与真正卡住的区别**:

| 特征 | Burst 模式（正常） | 真正卡住 |
|------|-------------------|---------|
| levels_done 变化 | 可能长时间不变（数据收集期） | 长时间不变 |
| **当天有 bot 目录?** | ✅ 有，今天产出的 | ❌ 无，最后目录是昨天或更早 |
| CSV 文件完整性 | ✅ T1-T5 级都有数据 | ❌ 目录存在但无 CSV 或不全 |
| `auto-batch-request.json` | 可能存在（等待消费）或不存在（批次间间隙） | 不存在且长时间无变化 |
| `pipeline-progress.json` mtime | 可能更新（驱动脚本写回进度） | 超 24h 未更新 |
| 过去 2 小时内有活动? | ✅ 有（检查 2h 窗口而非 30min） | ❌ 无 |

**看门狗处理建议**:

当 `levels_done` 未变化但当天有 bot 活动时，看门狗应按以下逻辑处理而非直接判卡住：

1. 放宽时间窗口：检查**过去 2 小时**而非 30 分钟内的活动
2. 优先检查当天是否有 bot 目录：`ls -lt telemetry/bot/ | grep "$(date +%Y-%m-%d)"`
3. 检查 CSV 文件完整性确认批次真正完成
4. 检查 `auto-batch-request.json` 和 Unity 日志判断驱动是否还在工作
5. 只在 **当天无 bot 目录 + 24h 无 levels_done 变化**时判卡住

---

## 看门狗投递策略（Cron Job 告警抑制与升级）

> **问题：** 连续 N 次相同报告 → 用户被重复告警骚扰，看门狗失去有效性。
> **目标：** 第一次明确告知，第二次升级，第三次及以后静默直到状态变化。

### 连续卡住状态下的投递规则

| 连续卡住计数 | 投递行为 | 说明 |
|-------------|---------|------|
| 第 1 次检测到卡住 | ✅ 完整报告 + 🔴 大红色判定 | 首次出现问题，全面诊断 |
| 第 2 次连续卡住 | ✅ 简要报告 + 与上次对比 + ⚠️ 升级标记 | 确认问题不是偶发 |
| 第 3+ 次连续卡住 | **[SILENT]** | 状态未变，不再重复投递。直到 levels_done 或 bot 目录有新活动才恢复 |

### 实现方式

`pipeline-progress-check.json` 新增字段 `stuck_count`：

```json
{
  "stuck_count": 2,
  "last_stuck_alert": "2026-07-07 16:55"
}
```

**检查逻辑：**

```
if levels_done 变化 OR 有新 bot 目录 OR progress.json mtime 比 last_progress_update 新:
    reset stuck_count = 0
    输出完整报告（🟢 恢复）
elif stuck_count == 0:
    stuck_count = 1
    输出完整报告（🔴 首次卡住）
elif stuck_count == 1:
    stuck_count = 2
    输出简要升级报告（⚠️ 第二次卡住）
else:
    stuck_count += 1
    不输出报告 → [SILENT]
```

> ⚠️ **关键细节：** 恢复判定中，**progress.json 的 mtime 更新**是一个独立的活性信号，与 levels_done 是并列关系。即使 levels_done 没变，mtime 更新也说明有脚本在写进度——管道仍在工作。检查时应比较 `stat progress.json` 的 mtime 与 checkpoint 中的 `last_progress_update`。

**恢复判断优先级（一种即视为恢复）：**
1. `levels_done` 比 last_check 增加 → 推进了
2. 最近 30 分钟有新 bot 目录 → 有活动
3. `pipeline-progress.json` 的 `last_progress_update` 比上次检查新 → 有人改过

### ⚠️ 禁止无上限重复投递

看门狗 cron 可能每分钟、每 15 分钟或每 1 小时运行。如果每次运行都投递同样的 \"管道卡住\" 报告，用户会收到数十条重复通知。

**硬规则：** 当 `stuck_count >= 2`（即已投递过至少两次卡住告警）且除 `stuck_count` 外无其他字段变化时，必须 [SILENT]。

**例外（即使 stuck_count 高也要投递）：**
- `levels_done` 变了（哪怕只+1） → 恢复报告
- 新 bot 目录出现 → 恢复报告
- Unity 进程从运行变为消失 → 新异常，重新报告

---

## 综合判定规则

| levels_done 变化 | 30分钟内新 bot 目录 | auto-batch-request.json | Unity 状态 | 外部驱动进程 | monitor_bot.py | 结论 |
|---|---|---|---|---|---|---|---|
| 无 | 无 | 不存在 | 已退出 | 无 | — | 🔴 **卡住** — Unity 已退出，外部驱动已停，bot 目录可能仍有（最后批次残留） |
| 无 | 无 | 不存在 | 运行中 | 有（monitor_bot.py） | ⏳ 运行中 >5min | 🔴 **monitor false negative** — export 已写完但 monitor 启动太晚，永远等不到 mtime 变化。数据就绪，杀 monitor 后手动推进 |
| 无 | 无 | 不存在 | 运行中 | 有（其他） | — | 🟡 **刚刚完成** — bot 目录是最后批次残留，Unity 刚退出，无下一请求 |
| 有 | 有 | — | 运行中 | 有 | — | 🟢 **正常运行** |
| 无 | 无 | 存在 | 运行中 | 有 | — | 🟡 **批次运行中** — request 未消费，大概率在跑 |
| 无 | 有 | 不存在 | 运行中 | 有 | — | 🟢 **正常运行** — 驱动在写下一个 request |
| — | — | — | 不存在 | — | — | 🔴 **Unity 进程已退出** — 可能是崩溃 |
| 无 | 有（同关卡重复） | 不存在 | 运行中/已退出 | 无 | — | 🔴 **同关卡空转** — 无外部驱动，管道在同一关反复跑 |
| **无（14h+）** | **有** | **存在** | **运行中** | **有（monitor 在旧目录）** | — | 🟡 **长批次进行中** — levels_done 冻结 + 持续有新 bot 目录 + Unity 日志活跃。这是'数据收集模式'，不是卡住。但需确认 Unity 日志 mtime < 5min 以确认还在跑 |
| **无** | **有（新目录为空）** | **存在** | **运行中** | **有** | — | 🟢 **批次切换中** — 旧批次刚完成，新请求已提交，Unity 准备写入新目录 |
| **无** | **无（当天有 + CSV 完整）** | 不存在 | 运行中 | 无/有 | — | 🟡 **Burst 间歇期** — 当天有 bot 产出（含 CSV 数据），但当前处于批次间间隙。放宽时间窗至 2h 再判。不是真卡住，但需关注如果超过 2h 也无下一轮活动 |
| **无** | **无（T1–T5 齐全）** | **不存在** | **运行中** | **无** | — | 🔴 **Post-Batch Stall** — 批次成功完成（T1–T5 齐全），外部驱动未提交下一请求。数据就绪未消费。详见 §9 |

---

## 建议处理动作

### 卡住时

1. 检查 Unity Editor.log 最后是否有异常（崩溃/编译报错/无限等待）
2. 检查 BuildLogs 下是否有 crash dump
3. 重启流程：
   - 确认 Unity 活着 → 手动注入 `auto-batch-request.json` 恢复流程
   - Unity 已死 → 启动 Unity，等待就绪后写入第一个 request
4. 如 `pipeline-progress.json` 明显落后于已实际完成的关卡，手动更新或触发驱动脚本补写

### 通知模板

```
⚠️ 管道可能卡住
进度: {levels_done}/{levels_total} 关完成 ({scope})
最后活动: {minutes_ago} 分钟前（{last_bot_dir}）
Unity 状态: {running/idle/crashed}
外部驱动: {running/stopped}
建议: {action}
```

---

## 已知坑

1. **`levels_done` 可能不是实时进度** — 如上所述，progress.json 可能数日不更新而批次仍在跑。以 bot 目录 mtime + auto-batch-result.json 为更实时的信号。
2. **`levels_done` 字段与 `done` 数组长度可能不一致** — 2026-07-06 实测：`levels_done: 8` 匹配 `done` 数组的 8 个元素，但之前检查曾误报为 9（人工计数或混入 `勉强`/`已优化` 关卡）。**始终数 `done` 数组长度**，不直接信任 `levels_done` 数值字段。
3. **没有外部驱动脚本 = 必然卡住** — 2026-07-06 三次连续检查（13:14、13:47、14:19）均证实：一旦 `auto-batch-request.json` 被消费，无外部脚本写入下一个，管道必然停留在当前关卡空转。这是**确认的规律**，不是偶发。
4. **Bot 目录活动可能短暂超出 Unity 生命期** — Unity 退出前的最后批次仍会写入 bot 目录，导致出现 "Unity 已死但 bot 目录在 30 分钟内" 的窗口期。此时看门狗应标记为 "刚刚完成" 而非 "正常运行"。
5. **`pipeline-progress-check.json` 作为历史记录** — 该文件记录上次检查快照，初次运行或无此文件时无法做 delta 判断（`levels_done` 变化比较），只能基于 bot 目录和 request 文件状态做单项判断。
6. **进程名冲突** — `tasklist` 输出的 Unity 进程可能是其它 Unity 项目，需确认 projectPath 匹配。通过 `unity-launch-test.log` 的启动参数确认。
7. **Hermes python 进程干扰** — `tasklist | grep python` 会显示多个 Hermes 后台进程，需用 `wmic` 或 `ps aux` 区分是否为管道驱动脚本。
8. **pipeline-progress.json 的手动修改** — 如果人工介入调整进度，levels_done 可能跳变，看门狗应容忍非递减变化（如 9→12 或 9→10），但 9→9 可能为正常（处理中的关卡还未标记完成）。
9. **`monitor_bot.py` false negative（永久等待）** — monitor_bot.py 进程存活 + `auto-batch-last-export.txt` 和 `auto-batch-result.json` 存在且内容完整 + 无新 bot 目录 + Unity 运行中 = monitor 启动太晚错过了信号。检查方法：对比 `auto-batch-last-export.txt` 的 mtime 与 monitor 进程启动时间（`ps -p <pid> -o lstart` 或 `stat /proc/<pid>/`）。如 export mtime 早于 monitor 启动时间 → 已中 false negative。恢复：杀 monitor 进程，直接读 result.json 的 export 路径取数据，手动推进 pipeline。
10. **`pipeline-progress-check.json` 的 `done_array_count` 自检** — 2026-07-08 检测发现 `levels_done=15` 可以与 `done` 数组长度交叉验证（均应为 15）。推荐每次检查记录 `done_array_count` 字段，不一致时预警 JSON 可能损坏或手动修改过。详见 `references/checkpoint-schema.md`。
