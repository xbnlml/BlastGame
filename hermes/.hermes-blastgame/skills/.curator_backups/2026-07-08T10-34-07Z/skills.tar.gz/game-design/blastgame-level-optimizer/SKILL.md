---
name: blastgame-level-optimizer
description: "BlastGame 多档位全自动调优管道。批处理模式：批A(agent检索+设计)→批B(terminal提交+轮询)→批C(agent判定+记录)。走7步流程：检索→设计→提交→触发→监控→判定→记录。逐关或批处理。"
version: 2.9.0
author: Hermes Agent
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [blastgame, game-design, level-optimizer, pipeline]
    related_skills: [blastgame-multi-tier-designer, blastgame-bot-orchestrator, blastgame-auto-pipeline]
---

# BlastGame 单关调优流程

> 处理**一关**的完整调优。每步标注了调用的脚本。

**前置加载：** `blastgame-multi-tier-designer`（规则）+ `blastgame-bot-orchestrator`（批跑）+ 设计探针前加载 `blastgame-multi-tier-designer references/probe-design.md`

---

## 操作守则（违反必被骂）

0. **所有模式通用：** 执行任何操作性动作前，先以"计划：[具体操作]"说明，然后问"要执行吗？"。等用户明确回答"好/可以/执行"（或相近语义）后才动手。用户没回答或说别的，一律不动。执行完展示结果。
1. **正常模式：** 0 号规则基础上，执行完展示结果。改完asset等后续指令，不自动提交request。
2. **全自动模式（用户表达"全自动/我人不在了/你搞定"或相近意思时）：**
   ❌ 不展示方案，不等确认，不问问题，不写 asset/Excel
   ✅ **批处理模式：所有 pending 关同时过同一 Step，不走逐关循环。** 决策步骤（Step 2/6）agent 分批加载 skill 文件做；机械步骤（Step 3-5）一次性 terminal 提交
   ✅ 批A (Step1+2): agent 检索全部关 + 设计全部 R1 探针 → 写入 progress
   ✅ 批B (Step3-5): terminal 逐一 patch/focus/submit/wait，全部完成后通知 agent
   ✅ 批C (Step6+7): agent 逐关加载 judgment-rules.md 判定 + 记录
   这是全自动的基础设定，不可更改。
3. **不一定同意用户** — 用户的想法你觉得不合理可以说出来。不是每次讨论都要改东西，当前版本合理就不动。
4. **不做用户没要求的事** — 用户说"改asset"就只改asset，不等他让跑就不跑
5. **白跑不计轮次** — asset没刷新、配置不对等故障导致的数据无效，不消耗6轮探针上限
6. **展示最佳方案再判** — 穷举全部数据后把最接近目标的组合给用户看，等用户拍板。不自己判死刑
7. **自动结论** — 第6轮仍不合格自动标记接近/改关卡，不等待确认
8. **禁止随意重启 Unity** — 编译通过聚焦触发。卡死/崩溃时重启 Unity 是故障修复，不受此限。

---

## P0 — 对话恢复

三步定位后输出当前阶段 + 下一步方案，问"要执行吗？"等待授权。

1. **查 memory + fact_store** — `probe(entity="L{level} tuning discussion")` 看历史讨论
2. **查 pipeline-progress.json** — 看断点位置和已有关卡状态
3. **查 tuning-records.md** — 该关是否有之前记录的最佳方案

---

## 7 步流程

### Step 1 — 检索

**调用：** `scripts/get_level_data.py` — 跨所有数据源查指定关卡

> **配置变更过滤：** 如果 progress.json 中该关有 `config_changed_at` 字段，检索时应只取该时间戳**之后**的 Bot 数据。之前的旧数据因用户改过关卡配置而无效。

> **⚠️ 目录扫描范围：** `telemetry/bot/*/` 包含各种前缀的目录（`70-70-*`、`52_54_64-*`、`55_59-62-*` 等）。**不要限定前缀模式**——用 `glob("telemetry/bot/*/")` 覆盖全部，实测 56+ 个目录。只搜 `5*/` 或单关前缀会漏数据。
>
> **⚠️ Opt CSV 列名：** `multi-tier-opt/` 下的 summary CSV 使用 `GameLevel`（不是 `level`）和 `VerifiedWinRate`（不是 `winkate`），取值是十进制（0.71=71%），需 `*100`。
>
> **同关多次跑会在 bot/ 下生成多个批跑目录。** 必须遍历全部同名前缀目录，不能只取第一个——否则漏失后续轮次的最新数据（如 L57 漏了批跑目录中的最新配置）。

**输出：** 表格（一档一行），含来源标注

### Step 2 — 设计探针

**先加载 probe-design.md 参考文件（`references/probe-design.md`），对照需求驱动流程 + 调参经验 + 缺口分析方法再设计。** 不得凭感觉直接写探针。

**⚠️ 探针方向判断陷阱：** 问题往往是"哪个标准没满足"，不是"哪个区域数据少"。T1→T3=18pp<20pp 时，应打 T3 方向解决 gap，不是打 T5 方向填数据空白。

**缺口分析：** 目标（`lv_win_config_test.xlsx`） vs 已有最接近值。缺口 5pp 以内视为已通过、不分槽。>5pp 是主攻方向。
**原则：** 已验证配置不放探针；每槽预期 WR 必须有明确目标

**第 1 轮（宽谱）：** 5 槽覆盖从极容易到极难的全范围。Normal 关也跑全 5 档（tiers=1,2,3,4,5）不要只跑 3 档——第 1 轮的目的是摸清 WR 全范围，不是验证最终组合。第 2 轮起才按缺口集中分配。

**第 2+ 轮（定向补缺，需求驱动）：**

1. **需要哪些 WR？** 从档差规则反推合格组合需要各档在什么 WR 范围
2. **按数据源优先级查已有：** Bot → Summary → Phase2 → Phase1 → 自推。查具体 sd/ratios 组合（非按 WR 范围），已有覆盖不给槽
3. **缺哪些 WR 段？** 对比需求 vs 已有，缺口处就是探针方向
4. **设计探针：** 5 槽全打缺口段，每槽标来源（Phase2/Phase1/自推）+ 预期 WR
5. **四参数全可调：** sd/sc/ratios/of，不限 sd。降低 of 通常提高 WR

**⚠️ 查缺前必须过数据源优先级：** Bot → Summary → Phase2 → Phase1 → 自推。按具体 sd/ratios 逐源查。Phase2 候选比 Phase1 优先级高。已有候选的直接写探针验证，不凭空猜新 sd。

此时 Normal 可用 tiers=1,3,5 节省时间。局数可用 200 局（±3.5% 误差够判方向），不必每轮都跑 400 局。

**调用脚本（按情况选）：**
- `scripts/slot_probe_80_100.py` — 生成五槽位探测方案
- `scripts/phase2_combo_80_100.py` — 从Phase2选组合方案
- `scripts/cross_source_analysis.py` — 跨来源整合数据
- `scripts/check_invert_swap.py` — 检查倒挂

**输出：** 5档探针配置表

### Step 3 — 提交

**备份现存 asset 配置：** patch 前先读当前 sd 值，防止改错了需要恢复。

```python
import re
with open(os.path.join(REPO, f"Assets/GameModule/GameMain/ConfigSo/Generated_enum/test/{level}.asset")) as f:
    sds = re.findall(r"StartDifficulty: (\d+)", f.read())
with open(os.path.join(REPO, f"BuildLogs/_asset_backup_{level}.txt"), "w") as f:
    f.write(",".join(sds))
```

**提交流程（单关或多关均可）：**
1. asset 文件 sd 已通过 grep 验证
2. 聚焦 Unity：`(New-Object -ComObject WScript.Shell).AppActivate("BlastGame")`
3. 等待 30 秒（编译 + AssetDatabase 刷新）
4. 写 `auto-batch-request.json`（`levelSpec` 支持逗号分隔或范围格式，如 `"89,90,91"` 或 `"89-95"`。一次 patch 全部 asset → 一次 submit → Bot 自动排队跑完）
5. **消费验证：** 提交后 120s 未消费 → delete-recreate request.json（删除→等3s→重写）→ 再等 120s。仍不消费 → 重启 Unity（故障恢复不是随意重启）
6. **跑后验证：** Bot 完成后，**只查提交后新出现的目录**（记录前状态→计算差值），不混历史目录。读 `campaign-attempts.csv` 比对 `startDifficulty`。不等 → 白跑，不计入轮次。

⚠️ 禁止随意重启 Unity。编译通过聚焦触发。卡死/崩溃时重启 Unity 是故障修复，不受此限。用 of=0.01 替代 of=0 避免 BlastInitialQueueBuilder 崩溃。

### Step 4 — 触发

PollForRequest 每 5 秒自动轮询，Unity 失焦时正常运转。

**确认消费：** request.json 被删 = 已拾取。⚠️ 运行期间 request.json 不会被删（代码顺序：RunBot → WriteResult → TryDelete），所以 request.json 存在 + Editor.log 有 "Bot Batch" = 正在跑。

### Step 5 — 监控

**方法：** 前台轮询，不依赖后台进程。

1. **记录前状态：** 提交前记下 `auto-batch-last-export.txt` 的 mtime 和 `telemetry/bot/{lv}-{lv}-*` 的目录集合
2. **轮询（每 2 秒）：** mtime 变了，或者有新的目录出现（减去前状态的目录集合）
3. **读取结果：** 只查最新目录的 5 档，不混历史数据
4. **超时 360 秒：** 超时后检查 Unity 进程 → 重启 Unity → 重试

**白跑验证（跑完后即做）：** Bot 完成后，读 `campaign-attempts.csv` 的 startDifficulty，比对是否等于探针配置。不等 → 白跑，不计入轮次，修复后重跑。

### Step 6 — 判定

**加载 judgment-rules.md 后逐条过检查：**
`skill_view(name="blastgame-multi-tier-designer", file_path="references/judgment-rules.md")`
1. 过⑥改关卡预判（span<15/可疑15-24/可跑≥25，命中直接标记改关卡）
2. 过②合格判定表（查各档WR是否及格）
3. 过③硬性违规清单（档差<5%/倒挂/T3锚点等，逐条核对）
4. 过④档差审美（>50%需15-35pp，<50%需5-25pp，递减≤4pp）
5. 过⑤结果分级，根据情况继续或入库
6. 过品质线（各档离目标≤10pp）

**不得凭记忆判断规则。**

**数据不足：** Normal 有效配置<3（或 Hard/SuperHard<5），不足以找组合，继续批C下一关。

**轮次上线：** 每关最多 6 轮。progress.json 中 `rounds[lv]` 记录已跑轮数。每经一次 Step 5（监控完成）递增 1。达到 6 轮后无论结果强制输出结论进入下一关。

**可调用脚本（根据情况选）：**
- `scripts/analyze_round3_bot.py` / `analyze_slot_probe_bot.py` / `analyze_multitier_opt.py` 等
- `scripts/eval_levels.py` — 通用评估
- `scripts/check_invert_swap.py` — 检查倒挂

**过检查表三张（必须 load multi-tier-designer 看原文）：** ①数据源 ②合格 ③结果

### Step 7 — 入库 / 重试

**入库 3 步（缺一不可）：**

1. **写入 asset** — patch `DynamicDifficultyConfigs:` 为最终 5 档配置
2. **写入手动挑配置记录.xlsx**：⚠️ 列结构：A=关号 B=难度名 C=档位 D=WR E=sd F=sc G=ratios H=of。先 unmerge 清除合并，再按正确列写入
3. **写入 tuning-records.md** — 记录最终配置、WR、判定结论

**完成状态标注规则（正常模式）：**
- ✅ **完成**（用户确认） → 执行入库 3 步，写入 asset + Excel + tuning-records
- ⚠️ **待确认**（接近目标但差一点） → 仅记录 tuning-records.md，等用户核验
- ⏹ **Agent完成**（天花板无法解决，跳过的） → 仅记录 tuning-records.md

**全自动模式下各结果的处理：**

| 结果 | 记录到 tuning-records | 改 asset/Excel | 关卡操作 |
|------|---------------------|---------------|---------|
| ✅ 合格 | ✅ 含完整数据池 | ❌（等用户确认） | 继续下一关 |
| ⚠️ 接近（还有轮次） | 不记录 | ❌ | 回到 Step 2 继续探 |
| ⚠️ 接近（第6轮） | ✅ 含完整数据池 | ❌ | 继续下一关，标记待确认 |
| ❌ 远不合格（还有轮次） | 不记录 | ❌ | 回到 Step 2 继续探 |
| ❌ 远不合格（6轮耗尽） | ✅ 完整数据池+标记改关卡 | ❌ | 继续下一关 |

自动模式下永远不写 asset/Excel，等用户回来核验后说"入库"才执行入库 3 步。

**每次记录必含内容：**

无论合格/接近/不合格，tuning-records 都需包含：

1. **全部配置排序表** — 所有 Bot 实测配置，一档一行（WR/sd/sc/ratios/of），按 WR 降序。不管是否用于最终组合
2. **最佳组合表** — T1-T5 各档选出的配置及 gaps
3. **全规则判定结果** — 过 judgment-rules ②③④⑤ 各项的结论
4. **来源/轮次说明** — 用了多少轮、最终 400 局验证结果

用户不需去数据文件夹补查。没有全量配置表的记录视为未完成。

---

## 循环控制（全自动模式）

**批处理：** 所有 pending 关同时过同一 Step。

1. 批A（Step1+2）：agent 检索全部 pending 关数据 → 设计各关 R1 探针 → 写入 progress
2. 批B（Step3-5）：一次性 patch 全部 asset → 一次性提交 `levelSpec="全部pending关"` → Bot 自动排队跑完。**multi-level submit：** `auto-batch-request.json` 的 `levelSpec` 支持 `"89,90,91"` 或 `"89-95"` 格式，一次提交自动串行跑。每关完成后记 progress，被杀了从断点续
3. 批C（Step6+7）：agent 逐关加载 judgment-rules.md 判定 → 记录

**关键：** 机械步骤（批B）是单次 terminal 调用的顺序循环，不会跨会话中断。决策步骤（批A/批C）在 agent 内逐关执行，每次加载对应 skill 文件。

**卡死处理：**
- request 未消费（>120s）：聚焦 Unity → 等 60s → delete-recreate request → 等 120s。3 次重试仍不消费 → 重启 Unity → 重新提交
- export 超时（>10min）：检查 export 目录 → 有数据则读 → 无数据则聚焦再等 5min → 仍无则重启 Unity → 重跑该关
- Unity 崩溃（进程消失）：自动重启 Unity（杀进程→重开→等 ready→继续）

**中断恢复：** 批A/批C 被中断 → 从 progress.json 继续当前批量。批B 被中断 → 检查 export 目录，已完成的关跳过，未完成的从第一关重新提交。

**request 消费超时：** 提交后 120s 未消费 → 聚焦 Unity（AppActivate timeout=5）→ 等 60s → 仍不消费则 delete-recreate request → 再等 120s。3 次重试仍不消费 → **重启 Unity**（杀进程→重开）→ 等 ready → 重新提交。不跳过该关。

**monitor/export 超时：** monitor_bot.py 未通知 >10min → 检查 export 目录有数据则读 → 无数据则检查 Unity 进程 → 进程存在则聚焦再等 5min → 仍无则**重启 Unity** → 重新提交。不跳过该关。

**Unity 崩溃（进程消失）：** 自动重启 Unity（`Unity.exe -projectPath ...`）。等 ready → 继续执行。这是故障恢复不是随便重启。

**全部完成后：** pending 列表变空 → 输出汇总表 → 显式停止流程。

---

## 每关决策记录（fact_store）

主观判断无法用规则表达，必须记下来跨对话回看。

**保存：** 关键讨论节点或 Step 6 判定后
```python
fact_store(action="add", entity=f"L{level} tuning discussion",
  content="决策依据和数据", tags=[f"L{level}", "decision"], trust_delta=0.9)
```

**恢复：** 新对话 `probe(entity="L63 tuning discussion")`

**不写进 memory：** memory 每轮全量注入，每关细节存 fact_store 按需检索。

---

## 脚本

| 脚本 | 用途 | 位置 |
|------|------|------|
| `get_level_data.py` | Step 1 数据检索 | `scripts/` |
| `monitor_bot.py` | Step 5 监控（后台备选） | `~/AppData/Local/hermes/scripts/` |
| `submit_batch.py` | **Step 3-5 批量提交+轮询（主力）**。patch 全部 asset → 一个 request → 等全部新目录 → 输出结果。支持逗号分隔多关 | `~/AppData/Local/hermes/scripts/` |

> 聚焦编译：AppActivate（`subprocess.Popen` 非阻塞）→ 30s等待 → 提交。不要重启 Unity。

## 参考文件

| 文档 | 位置 | 用途 |
|------|------|------|
| `judgment-rules.md` | `multi-tier-designer/references/` | 判定规则（合格表/硬性违规/审美/改关卡预判） |
| `probe-design.md` | `multi-tier-designer/references/` | 探针设计（需求驱动流程/调参经验/缺口分析） |
| `stall-recovery.md` | `references/` | 卡死恢复（request超时/export超时/Unity崩溃） |
| `pipeline-watchdog.md` | `auto-pipeline/references/` | 管道卡住诊断与看门狗（cron job 检测+投递策略） |
| `ForceRefresh.cs` | `templates/` | AssetDatabase.Refresh 强制刷新模板 |

---

## 常见错误

1. **检索漏范围模式** — bot/ 目录有单关、逗号、范围 3 种模式，只搜一种是典型错误
2. **patch 后不验证直接提交** — Unity 没重载就白跑。提交前 grep 确认文件内容正确，跑后读 attempts CSV 二次验证
3. **Agent 自作主张往前跳** — 只做用户明确要求的。没让做就不做
4. **数据异常时自行推断结论** — sd-WR 没有单调关系。展示数据让用户判断，不替用户下结论
5. **文字不用表格** — 多档位数据必须表格展示，一档一行，禁止纯文字叙述
6. **不先给方案直接跑** — 先展示配置+预期+理由，问"要执行吗？"等用户说好
7. **`write_file` 改 .asset** — .asset 是混合格式，覆盖即损坏。必须用 `patch`
8. **忽略 of 参数** — 四参数全可调，of 是强力辅助。步长 0.05，不能跳步
9. **跳步调 of** — of 在 0.3-0.5 区间响应陡峭，0.5→0.3 可能让 WR 翻倍。步长 0.02-0.05
10. **需求驱动方向判断错误** — 缺口分析不是"哪个区域数据少"，是"哪个标准没满足"
11. **跳过 Step 1 直接用 Phase2** — Phase2 WR 是模拟值，与 Bot 实测可能差 10-30pp。优先 Bot 数据
12. **Excel 列映射错误** — D=WR E=sd F=sc G=ratios H=of。写错列导致数据位置错乱
13. **focus Unity 超时/卡死** — AppActivate 用 subprocess.Popen(DEVNULL) 非阻塞调用
14. **轮询 export 时混入历史目录** — 提交前记前状态，提交后只查新目录
15. **提交失败/卡死时跳过该关** — 不跳过。重启 Unity 修复后重试。这是故障恢复，不是随意重启
