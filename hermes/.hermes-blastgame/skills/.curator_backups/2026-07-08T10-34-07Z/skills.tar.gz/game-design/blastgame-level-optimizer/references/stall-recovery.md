# 卡死/故障恢复参考

## request 消费超时（提交后 120s 未消费）

1. 聚焦 Unity：`(New-Object -ComObject WScript.Shell).AppActivate("BlastGame")`（timeout=5）
2. 等待 60s
3. 仍未消费 → delete-recreate request → 等 120s
4. 3 次重试后仍不消费 → **重启 Unity**（杀进程→重开）→ 等 30s → 重新提交
5. ⚠️ 不跳过该关

## monitor/export 超时（10min+ 无通知）

### 场景 A：monitor_bot.py false negative（启动太晚）

monitor_bot.py 在 `auto-batch-last-export.txt` **已写入后**才启动 → monitor 记录当前 mtime，进入死循环等变化 → 实际上批次已完成，但 monitor 永远不退出。

**识别：** `ps | grep monitor_bot` 确认进程存在且运行时间 >5min；对比 `auto-batch-last-export.txt` mtime 与 monitor 进程启动时间，前者早于后者。

**恢复（两步）：**
1. 杀 monitor 进程（`kill <pid>` 或 `process(action='kill', session_id=...)`）
2. 直接读 `BuildLogs/auto-batch-result.json` → 取 `outDir` 确认 export 数据完整性 → 跳过 monitor，直接进入 Step 6 判定
3. ⚠️ **不重启 Unity，不重新提交** — 数据已就绪，只是 monitor 没通知到

### 场景 B：真正超时（批次未完成）

1. 检查 `telemetry/bot/{lv}-{lv}-*/` 是否有数据 → 有则读结果继续
2. 无数据 → 检查 Unity 进程（PowerShell Get-Process Unity）
3. 进程存在 → 聚焦再等 5min
4. 仍无 → **重启 Unity** → 重新提交
5. ⚠️ 不跳过该关

## Unity 崩溃（进程消失）

1. 自动重启：`Unity.exe -projectPath ...`
2. 等 30s 确认 ready（grep "Internal_CallUpdateFunctions"）
3. 聚焦 Unity
4. 恢复中断的任务
5. ✅ 这是故障恢复，不是随意重启

## 全部完成

- pending 列表变空 → 输出汇总表（已完成关/待确认关/故障关）
- 显式停止流程
