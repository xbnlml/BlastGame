#!/usr/bin/env python3
"""Submit multiple levels in one batch. Patch all -> submit once -> wait for all."""
import json, os, time, glob, csv, re, subprocess, sys
REPO = r"C:\Users\Administrator\Documents\BlastGame"
WATCH = os.path.join(REPO, "BuildLogs/auto-batch-last-export.txt")
REQ = os.path.join(REPO, "BuildLogs/auto-batch-request.json")
def echo(m): print(m, flush=True)
def focus():
    subprocess.Popen(['powershell','-NoProfile','-Command',
        '(New-Object -ComObject WScript.Shell).AppActivate("BlastGame")|Out-Null'],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
LEVELS = [s.strip() for s in sys.argv[1].split(',')] if len(sys.argv)>1 else []
if not LEVELS: echo("Usage: python submit_batch.py '89,90,91'"); sys.exit(1)
n=len(LEVELS); echo(f"=== {n} levels ({','.join(LEVELS)}) ===")
pre_mtime=None
try: pre_mtime=os.stat(WATCH).st_mtime
except: pass
pre_dirs=set(os.listdir(os.path.join(REPO,"telemetry/bot")))
sds=[1,5,10,20,30]; scs=[5,5,4,5,5]
rats=["1,1,1,1,1","1,1,1,1,1","1,1,1,1","10,1,1,1,1","10,1,1,1,10"]
for lv in LEVELS:
    fp=os.path.join(REPO,f"Assets/GameModule/GameMain/ConfigSo/Generated_enum/test/{lv}.asset")
    lines=[]
    for i in range(5):
        lines.extend([f"    - StartDifficulty: {sds[i]}",f"      ShuffleSplitCount: {scs[i]}",
            f"      ShuffleSplitRatios: {rats[i]}",f"      ShuffleOverflowFactor: 0.5"])
    nb="    DynamicDifficultyConfigs:\n"+"\n".join(lines)
    with open(fp) as f: c=f.read()
    old=re.search(r"    DynamicDifficultyConfigs:.*?(?=\n    [a-z]|\Z)",c,re.DOTALL)
    if old: c=c[:old.start()]+nb+c[old.end():]
    with open(fp,'w') as f: f.write(c)
echo(f"Patched {n} assets")
focus(); time.sleep(30)
if os.path.exists(REQ): os.remove(REQ); time.sleep(2)
json.dump({'levelSpec':','.join(LEVELS),'runCount':200,'levelFolder':'test',
    'tiersCsv':'1,2,3,4,5','recordReplay':False,'tag':f'batch-{LEVELS[0]}-{LEVELS[-1]}'},open(REQ,'w'))
echo("Submitted")
for i in range(120):
    time.sleep(1)
    if not os.path.exists(REQ): break
else:
    d=json.load(open(REQ));os.remove(REQ);time.sleep(3)
    json.dump(d,open(REQ,'w'))
    for i in range(120):
        time.sleep(1)
        if not os.path.exists(REQ): break
    else: echo("FAIL"); sys.exit(1)
echo("Consumed")
start=time.time()
while time.time()-start < n*300:
    time.sleep(3)
    new_dirs=set(os.listdir(os.path.join(REPO,"telemetry/bot")))-pre_dirs
    completed=[]
    for d in new_dirs:
        p=d.split('-',1)
        if p[0] in LEVELS:
            tiers=[t for t in os.listdir(os.path.join(REPO,"telemetry/bot",d)) if re.search(r'T\d+',t)]
            if len(tiers)>=5: completed.append(p[0])
    if len(completed)>=n:
        echo(f"All done at {time.time()-start:.0f}s")
        for lv in LEVELS:
            m=[d for d in new_dirs if d.startswith(lv+'-')]
            if m:
                bd=os.path.join(REPO,"telemetry/bot",sorted(m)[-1])
                for td in sorted(os.listdir(bd))[:5]:
                    tdir=os.path.join(bd,td)
                    if not os.path.isdir(tdir): continue
                    mm=re.search(r'T(\d+)',td)
                    if not mm: continue
                    for sf in glob.glob(os.path.join(tdir,"campaign-summary-*.csv")):
                        with open(sf,encoding='utf-8-sig') as f:
                            for row in csv.DictReader(f):
                                if int(row['level'])!=int(lv): continue
                                echo(f"  L{lv} T{mm.group(1)}: WR={float(row['winkate'])*100:.1f}%")
                                break
        sys.exit(0)
echo("TIMEOUT"); sys.exit(1)
