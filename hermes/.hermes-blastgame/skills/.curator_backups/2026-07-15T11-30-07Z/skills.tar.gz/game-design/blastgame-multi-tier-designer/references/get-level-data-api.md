# get_level_data(lv)  — 数据检索函数

路径: `D:/download/Hermes/tools/get_level_pool.py` 或 `tools/data/pool.get_preferred_records(lv)`

## 返回值结构

```python
{
  'bot': [      # Bot 实测，按胜率降序
    {'wr': 88.0, 'sd': 23, 'sc': 5, 'ratios': '10,4,3,1,8', 'of': 0.5},
    ...
  ],
  'summary': {  # 优化器 Summary（如有）
    'batch': '51-75-...',
    'tiers': [
      {'tier': 'T1-超高胜率', 'wr': 90.5, 'sd': 23, 'sc': 5, 'ratios': '10,4,3,1,8', 'of': 0.5},
      ...
    ]
  } or None,
  'phase2': [   # Phase2 候选，按胜率降序
    {'wr': 96.0, 'sd': 20, ...}, ...
  ],
  'phase1': [   # Phase1 原始，按胜率降序
    {'wr': 97.0, 'sd': 25, ...}, ...
  ]
}
```

## 注意事项

- 自动处理两种 bot 目录结构（扁平/嵌套）
- 自动去重：相同 (sd, sc, ratios, of) 只保留第一个
- 只读取 >0 且非空 sd 的配置（跳过基线/无效数据）
- utf-8-sig 编码处理 BOM
