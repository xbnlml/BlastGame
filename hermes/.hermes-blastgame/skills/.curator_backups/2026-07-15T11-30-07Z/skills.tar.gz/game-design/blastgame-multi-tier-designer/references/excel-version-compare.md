# 手动挑配置记录 版本比较

## 不要看文件修改时间判断新旧

用户可能从不同分支拷贝了不同版本。修改时间只能反映"什么时候拷的"，不能反映"数据哪个更新"。

## 正确方法：比较内容

对比关键关卡的 WR 值：

```python
import openpyxl

def compare_excel(path_a, path_b, check_levels):
    wb_a = openpyxl.load_workbook(path_a, data_only=True)
    wb_b = openpyxl.load_workbook(path_b, data_only=True)
    # ... 对比 check_levels 的 WR 值
```

## 哪版更新？

追踪今天改动过的关卡（入库/修改的）的 WR 值：
- 有今日验证数据（如 L52 T3=40.0%、L65 T1=67.5%）的版本 = 新版
- 用旧数据的版本 = 旧版
