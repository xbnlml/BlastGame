# 配置数据源追溯方法

## 核心原则

**用 sd/sc/ratios/of 四元组匹配，不用档位标签或胜率匹配。**

Excel 的 T1 不一定是数据源的 T1。同一个配置在不同阶段可能被放在不同档位。只有四元组是唯一标识。

## 数据源（按优先级）

| 优先级 | 来源 | 文件 | 配置列 | WR列 |
|--------|------|------|--------|------|
| ① Bot | campaign-attempts.csv | `telemetry/bot/*/*/campaign-attempts-*.csv` | startDifficulty, shuffleSplitCount, shuffleSplitRatios, shuffleOverflowFactor | 无WR列，需对应目录的 campaign-summary.csv |
| ② Summary_Verified | opt/summary.csv | `telemetry/multi-tier-opt/*/*/summary.csv` | StartDifficulty, ShuffleSplitCount, ShuffleSplitRatios, ShuffleOverflowFactor | VerifiedWinRate（Bot实测）或 EffectiveTargetWinRate |
| ③ Phase2 | opt/phase2_candidates.csv | 同上目录 | 同上 | WinRate（标定值） |
| ④ Phase1 | opt/phase1_raw.csv | 同上目录 | 同上 | WinRate（原始采样） |

## 关键文件说明

### campaign-summary.csv（容易误用）

```csv
LevelGroup,level,DifficultyLevel,failBucketDistribution,winCount,failCount,winkate
```

**无配置参数。** 只有 level + tier + winkate。不能用来反查「这个 Bot 跑的是什么配置」。

### campaign-attempts.csv（真源）

```csv
LevelGroup,level,attemptIndex,seed,won,timeSec,endReason,...,startDifficulty,shuffleSplitCount,shuffleSplitRatios,shuffleOverflowFactor,...
```

**有配置参数。** 取前 3 行的 startDifficulty/shuffleSplitCount/shuffleSplitRatios/shuffleOverflowFactor 即可确认 Bot 运行时用的配置。

### opt/summary.csv（最优来源）

同时有配置参数和 Bot 实测 WR（VerifiedWinRate）。是最便捷的数据溯源来源——不需要跨文件关联。

## 实际操作步骤

### 步骤1：读 Excel 配置

```python
def norm_ratios(r):
    if not r: return ""
    try: return ",".join(str(int(float(x))) for x in str(r).replace(" ","").split(",") if x.strip())
    except: return str(r).replace(" ","").strip()

def cfg_key(sd, sc, ratios, of_val):
    return (int(sd), int(sc), norm_ratios(str(ratios) if ratios else ""), round(float(of_val if of_val else 0), 3))
```

### 步骤2：查 opt/summary.csv

按 (lv, cfg_key) 索引 summary.csv，取 VerifiedWinRate 或 EffectiveTargetWinRate。

### 步骤3：查 campaign-attempts.csv（如 opt 无匹配）

按 (lv, cfg_key) 索引，取前 3 行确认配置匹配，再读对应 summary.csv 的 winkate。

### 步骤4：查 Phase2/Phase1

如上述均无匹配，查 phase2_candidates.csv 和 phase1_raw.csv 的 WinRate（标定值，未Bot验证）。

## 四元组归一化陷阱

不同文件中的 ratios 格式不同：
- `"1, 10, 1, 1, 1"`（带空格）
- `"1,10,1,1,1"`（无空格）
- `"1,10,1,1,1,"`（尾逗号）
- `None` / 空字符串
- `""`（空字符串，如 sc=1 时无 ratios）

必须统一归一化后再比较。
