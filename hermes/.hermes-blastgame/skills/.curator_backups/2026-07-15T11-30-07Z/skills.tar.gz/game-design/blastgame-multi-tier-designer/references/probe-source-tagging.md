# 探针来源标注方法

按 sd/ratio 具体值逐源匹配，不是按 WR 段推断。

## 正确方法

```python
# 对每个探针槽位的 (sd, sc, ratios) 组合：
# 1. 在 Bot 数据中查是否有同 sd/ratios → 标 Bot
# 2. 没有则查 Phase2 candidates → 标 Phase2
# 3. 没有则查 Phase1 raw → 标 Phase1
# 4. 都没有 → 标 自推

def find_source(sd, rat, sc, of, bot_data, phase2_data, phase1_data):
    k = f"{sd}_{sc}_{rat}_{of}"
    if k in bot_data: return "Bot"
    if k in phase2_data: return "Phase2"
    if k in phase1_data: return "Phase1"
    return "自推"
```

## 常见错误

**❌ 按 WR 范围推断：** "这个 WR 段 40-60%，Bot 没跑过，所以标 Phase1"
→ 正确做法：查 sd=34 r=10,1,10,0,10 这个具体组合在 Phase2 有没有。如果有，标 Phase2 不是 Phase1。

**❌ 只看 sd 不看 ratio：** "sd=34 是 Phase1 的"
→ 不同 ratio 可来自不同数据源。sd=34 r=10,1,10,0,10 可能在 Phase2，sd=34 r=9,1,10,1,10 可能在 Phase1。

**❌ 自推定太少：** "这个 WR 段 Bot 和 Phase 都没跑过，但我猜它来自 Phase..."
→ 不确定时标自推。自推表示该 sd/ratios 组合在所有数据源中均不存在。
