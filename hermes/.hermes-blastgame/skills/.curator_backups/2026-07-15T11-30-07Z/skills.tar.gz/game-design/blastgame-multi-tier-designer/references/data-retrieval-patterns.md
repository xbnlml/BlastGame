# 数据检索标准

检索每关数据时必须查全部 **3 种目录模式**：

## 单关模式
```
51-51-2026-07-04T01-15-21/L51-51-T1-.../campaign-attempts-*.csv
levelSpec="51"
```

## 多关逗号模式
```
51_55_57_59-62_69-2026-07-04T17-59-07/L51_55_57_59-62_69-T1-.../campaign-attempts-*.csv
levelSpec="51,55,57,59-62,69"
```

## 范围模式
```
L55-60-2026-07-03T12-25-31/L55-60-T1-.../campaign-attempts-*.csv
levelSpec="55-60"
```

## 批量数据
```
L51-100-*/L51-100-T*/campaign-summary-*.csv
```

## 读取要点

- **campaign-summary.csv** 有 BOM 头（`﻿`），必须用 `encoding='utf-8-sig'` 打开
- **campaign-attempts.csv** 的 `level` 列是多关合跑时可能有非预期的level值，必须 `try: int(level); except: continue`
- 同一关可能在多个目录中出现（旧跑 + 新跑），优先用最新时间戳的
- 不要跳范围模式 — 典型错误：搜了 `51-51-*` 和 `51_55_57_*` 但没搜 `55-60-*`
