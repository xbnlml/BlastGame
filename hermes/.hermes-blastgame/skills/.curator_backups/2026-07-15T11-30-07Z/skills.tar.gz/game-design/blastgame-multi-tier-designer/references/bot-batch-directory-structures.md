# Bot Batch Directory Structures

Bot batches have two directory structures. Scanning scripts must handle both.

## Type A: Nested (standard)

```
batch-dir-2026-07-01T12-00-00/
  L51-52-T1-...batch-range/
    campaign-summary-L51-52-T1.csv
    campaign-attempts-L51-52-T1.csv
  L51-52-T2-...batch-range/
    campaign-summary-L51-52-T2.csv
    ...
```

Batch = `os.path.basename(os.path.dirname(os.path.dirname(csv_path)))`

## Type B: Flat (L1-200 baseline batch)

```
L1-200-T1-2026-06-26T22-17-31.906-batch-range/
  campaign-summary-L1-200-T1.csv
  campaign-attempts-L1-200-T1.csv
  replays/
```

Batch = `os.path.basename(os.path.dirname(csv_path))`

## Detection

```python
parent = os.path.dirname(csv_path)
grandparent = os.path.dirname(parent)
if os.path.basename(grandparent) == 'bot':
    batch = os.path.basename(parent)      # Type B
else:
    batch = os.path.basename(grandparent)  # Type A
```

## Naming Patterns — How to Find a Specific Level

The `telemetry/bot/` directory contains batch directories. The batch directory name encodes the `levelSpec` that was submitted.

### Pattern: Single level

```
54-54-2026-07-01T23-38-08
```
Submited `levelSpec: "54"`. Directory starts with `{lv}-{lv}-`.

### Pattern: Multi-level comma-separated

```
52-53_56-2026-07-01T02-13-06
```
Submitted `levelSpec: "52,53,56"`. Commas in the spec become underscores in the directory name.

### Pattern: Range

```
L51-100-T4-2026-07-03T00-19-01.047-batch-range
```
Submitted levelSpec with range `"51-100"`, plus a `-T{n}-` suffix indicating which tier this batch was for. The `L` prefix and `-batch-range` suffix distinguish it from single-level dirs.

### How to search for level L63 in telemetry/bot/

Check a directory name if it contains level 63 by checking all three patterns:

```python
def dir_contains_level(dirname: str, level: int) -> bool:
    # Pattern 1: single level like 63-63-*
    if dirname.startswith(f"{level}-{level}-"):
        return True
    # Pattern 2: comma-joined like 52-53_56-* (underscores = commas)
    # Split on underscore, check each segment
    segments = dirname.split("_")
    lv_strs = []
    for s in segments:
        # Each segment might be "52" or "63" or a range "51-100"
        match = re.match(r"L?(\d+)-?(\d*)", s)
        if match:
            lv_strs.append(match)
    # ... (see get_level_data.py for full implementation)
    # Pattern 3: range like L51-100-*
    range_match = re.match(r"L(\d+)-(\d+)-T", dirname)
    if range_match:
        start, end = int(range_match.group(1)), int(range_match.group(2))
        if start <= level <= end:
            return True
    return False
```

See `scripts/get_level_data.py` for the canonical implementation.

