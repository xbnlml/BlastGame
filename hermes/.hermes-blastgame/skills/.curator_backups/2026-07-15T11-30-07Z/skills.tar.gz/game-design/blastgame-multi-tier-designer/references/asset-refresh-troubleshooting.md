# Asset Refresh 故障排查

## 症状

Bot 跑完后 campaign-attempts 显示的是**旧配置**（非探针配置）→ 白跑一轮。

## 原因

AssetDatabase 缓存未更新。.asset 文件内容改了但 Unity 的主进程 AssetDatabase 没加载新数据。

## 修复方法

### 方法 A：touch + 聚焦 Unity（优先）

```python
# 改完所有 .asset 文件后
import os, time

# 1. touch 所有改过的文件
os.utime(asset_path, None)

# 2. 聚焦 Unity（触发自动刷新）
import subprocess
subprocess.run(["powershell","-NoProfile","-ExecutionPolicy","Bypass",
    "-File","C:/Users/Administrator/AppData/Local/Temp/focus_unity.ps1"])

# 3. 等待刷新完成
time.sleep(10)

# 4. 提交 request
```

### 方法 B：_ForceRefresh.cs（备用）

写脚本调用 AssetDatabase.Refresh()，需要编译+domain reload 才能运行：

```csharp
using UnityEditor;using System.IO;using UnityEngine;
public static class _ForceRefresh{
    [InitializeOnLoadMethod]
    static void R(){
        var m=Path.Combine(
            Directory.GetParent(Application.dataPath).FullName,
            "BuildLogs/_refresh_done.txt");
        if(File.Exists(m))return;
        AssetDatabase.Refresh();
        File.WriteAllText(m,"done");
    }
}
```

然后 touch 现有 .cs 文件 + AppActivate 聚焦。

**⚠️ 方法 B 不可靠原因：** InitializeOnLoadMethod 在编译后排队执行，不保证顺序。如果其他脚本的 init 方法阻塞或耗时过长，_ForceRefresh 可能永远不会执行。方法 B 超时（90s）时退回到方法 A。

## 验证 Refresh 生效的最可靠方式

**不要读文件内容**（文件是你写的，读了也白读）。跑完 Bot 后读 campaign-attempts CSV 确认配置与新探针一致。

```python
import csv, glob
for af in glob.glob("telemetry/bot/{level}-*/L*/campaign-attempts-*.csv"):
    with open(af) as f:
        r = next(csv.DictReader(f))
        actual_sd = r['startDifficulty']
        # 比较 actual_sd 与探针期望值
```

如果不一致 → 白跑一轮，不计入 4 轮上限 → 修复 Refresh 后重跑。
