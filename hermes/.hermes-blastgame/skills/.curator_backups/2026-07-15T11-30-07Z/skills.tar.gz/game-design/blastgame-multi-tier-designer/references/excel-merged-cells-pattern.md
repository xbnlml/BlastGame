# 手动挑配置记录.xlsx — 关联储存格结构

Excel 文件每关 5 行（T1-T5），关号列（A列）用关联储存格合并为 5 行一组。

## openpyxl 读取方法

```python
import openpyxl

wb = openpyxl.load_workbook("Doc/手动挑配置记录.xlsx", data_only=True)
ws = wb.active

# 建立 row → level 映射（处理 merged cells）
level_by_row = {}
for mc in ws.merged_cells.ranges:
    if mc.min_col == 1:  # A列 = 关号
        top_val = ws.cell(mc.min_row, 1).value
        for r in range(mc.min_row, mc.max_row + 1):
            level_by_row[r] = top_val

# 补充未合并的单行
for r in range(2, ws.max_row + 1):
    if r not in level_by_row:
        v = ws.cell(r, 1).value
        if v:
            level_by_row[r] = v

# 读取某关全部 5 档
lv = 63
for r in range(2, ws.max_row + 1):
    if level_by_row.get(r) == lv:
        tier = ws.cell(r, 3).value  # Tier1~Tier5
        wr = ws.cell(r, 4).value    # win rate
        sd = ws.cell(r, 5).value    # startDifficulty
        # ... 读其他字段
```

## 字段说明

| 列 | 字段 | 说明 |
|----|------|------|
| A | 关卡 | 关号（merged，5行一组） |
| B | 难度等级 | normal/hard/superhard |
| C | 档位 | Tier1~Tier5 |
| D | 胜率 | 小数，如 0.822 = 82.2% |
| E | 起始难度 | StartDifficulty |
| F | 洗牌分段数 | ShuffleSplitCount |
| G | 洗牌比例 | ShuffleSplitRatios |
| H | 段间重排系数 | ShuffleOverflowFactor |
