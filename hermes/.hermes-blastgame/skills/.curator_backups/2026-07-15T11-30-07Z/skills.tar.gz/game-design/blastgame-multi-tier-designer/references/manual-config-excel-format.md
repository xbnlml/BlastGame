# 手动挑配置记录.xlsx 读取注意事项

该 Excel 使用 **合并单元格（merged cells）** 存储每关的 5 档数据：

- 列 A（关卡号）: 每 5 行合并（L52 的 T1-T5 共享一个合并单元格）
- 列 B 及之后的列：每个 tier 一行，不合并

```
A42:A46 合并 = L52
  row 42: Tier1  …  ← openpyxl 只读到此行的 A 值
  row 43: Tier2  …  ← openpyxl 读到 A 为 None
  row 44: Tier3  …
  row 45: Tier4  …
  row 46: Tier5  …
```

## 读取方法

```python
# 构建 行→关卡 映射
row_lv = {}
for mc in ws.merged_cells.ranges:
    if mc.min_col == 1:
        top_val = ws.cell(mc.min_row, 1).value
        for r in range(mc.min_row, mc.max_row + 1):
            row_lv[r] = top_val
# 再加非合并行
for r in range(2, ws.max_row + 1):
    if r not in row_lv:
        v = ws.cell(r, 1).value
        if v: row_lv[r] = v
```

## 注意事项

- `data_only=True` 读取缓存在的值，如果文件有公式且未重算，缓存在的值可能为 None
- 空行（有行号但所有字段为 None/0）表示该关有占位但未完成
- 已完成的关：wr > 0 且 sd 不为空
