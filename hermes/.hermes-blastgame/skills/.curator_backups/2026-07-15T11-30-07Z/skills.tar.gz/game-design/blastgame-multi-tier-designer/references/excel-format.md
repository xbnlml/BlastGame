# 手动挑配置记录.xlsx 格式

## 列结构

| A（关号，合并5行） | B（难度，合并5行） | C（档位） | D（通关率） | E（SD） | F（SC） | G（Ratios） | H（溢出因子） |
|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|

- 每关 5 行（Tier1~Tier5）
- A、B 列按关号合并 5 行
- D 列通关率为小数（0.915 = 91.5%）
- A、B 列在写入时通常已存在（由全表重构预填），只写 C-H 列

## 写入方式（正确）

```python
# 找到关号所在行
for r in range(2, ws.max_row+1):
    v = ws.cell(row=r, column=1).value
    if v and str(v).strip() == str(lv):
        tiers = [
            ('Tier1', 0.915, 20, 5, '1,1,1,10,1', 0.5),
            ('Tier2', 0.915, 20, 5, '1,1,1,10,1', 0.5),
            ...
        ]
        for i, (tier, wr, sd, sc, ratios, ofv) in enumerate(tiers):
            row = r + i
            ws.cell(row=row, column=3).value = tier  # C=档位
            ws.cell(row=row, column=4).value = wr    # D=胜率
            ws.cell(row=row, column=5).value = sd    # E=SD
            ws.cell(row=row, column=6).value = sc    # F=SC
            ws.cell(row=row, column=7).value = ratios # G=参数
            ws.cell(row=row, column=8).value = ofv    # H=OF
        break
```

## 错误写法（不要用）

```python
# ❌ enumerate(vals, 2) 从 B 列开始写——B 是难度，C 是档位名
# ❌ 25 个值横跨 B~Z 列——会污染 I~Z 列
```
