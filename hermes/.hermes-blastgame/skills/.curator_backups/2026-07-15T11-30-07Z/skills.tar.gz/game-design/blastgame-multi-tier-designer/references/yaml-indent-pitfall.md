# YAML 缩进陷阱 — .asset 文件批量修改

## 问题

批量修改 DynamicDifficultyConfigs 时，正则 `customCellDrawingListV2` 的缩进写错了：

```python
# ❌ 错误：5 空格
old_block = re.search(r"    DynamicDifficultyConfigs:.*?(?=\n     customCellDrawingListV2|\Z)", content, re.DOTALL)

# ✅ 正确：4 空格  
old_block = re.search(r"    DynamicDifficultyConfigs:.*?(?=\n    customCellDrawingListV2|\Z)", content, re.DOTALL)
```

## 后果

5 空格的正则永远匹配不到 4 空格的 `customCellDrawingListV2`，退回到 `\Z`（文件末尾），导致匹配范围变为：

```
DynamicDifficultyConfigs → 文件结尾
```

替换后只剩下 DynamicDifficultyConfigs 一节，后面所有内容（含手配牌面 `customCellDrawingListV2`）被全部删除。

## 影响

手作关卡（1000-2000 行）会丢失全部牌面数据。
程序化生成关卡（~47 行）没影响——它们本来就没有 `customCellDrawingListV2`。

## 修复

从老版备份拷贝回 `customCellDrawingListV2` 块，不要覆盖新版其他改动。

## 预防

批量改 asset 时先读一个已知文件确认正则缩进正确。建议先用小文件测试。
