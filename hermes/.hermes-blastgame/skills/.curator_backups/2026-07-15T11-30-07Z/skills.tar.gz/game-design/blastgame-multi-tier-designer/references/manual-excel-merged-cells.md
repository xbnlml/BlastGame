# 手动挑配置记录.xlsx 解析

该 Excel 的关卡列（A列）使用**合并单元格（merged cells）**，每 5 行一组（T1-T5）。

## 读取方法

```python
import openpyxl
wb = openpyxl.load_workbook("Doc/手动挑配置记录.xlsx", data_only=True)
ws = wb.active

# 构建行号→关卡号映射
row_lv = {}
for mc in ws.merged_cells.ranges:
    if mc.min_col == 1:  # 只处理 A 列
        top_val = ws.cell(mc.min_row, 1).value
        for r in range(mc.min_row, mc.max_row + 1):
            row_lv[r] = top_val

# 对非合并行也补充
for r in range(2, ws.max_row + 1):
    if r not in row_lv:
        v = ws.cell(r, 1).value
        if v:
            row_lv[r] = v
```

## 列结构

| 列 | 内容 | 说明 |
|----|------|------|
| A | 关卡号 | 5行合并（T1-T5共用） |
| B | 难度等级 | normal/hard/superhard |
| C | 档位 | Tier1~Tier5 |
| D | 胜率 | 小数，如 0.895 = 89.5% |
| E | startDifficulty | int |
| F | shuffleSplitCount | int |
| G | shuffleSplitRatios | 字符串，如 "1,1,10,1,1" |
| H | shuffleOverflowFactor | float，通常 0.5 |
