# 数据检索规范

## 目录匹配 — 3 种模式

调用 `get_level_data(level)` 时，脚本内必须检查全部 3 种目录命名模式：

| 模式 | 示例 | 判断规则 |
|------|------|---------|
| ① 单关 | `63-63-{timestamp}` | `startswith(f"{lv}-{lv}-")` |
| ② 多关逗号 | `52-53_56-{timestamp}` | `split("_")` 检查每段含 lv，段内可能还有范围 `66-67` |
| ③ 范围 | `L51-100-T4-{timestamp}-batch-range` | `re.match("L(\\d+)-(\\d+)", name)` 检查区间 |

## 结构类型 — Type A vs Type B

| Type | 特征 | CSV 位置 |
|------|------|---------|
| A（嵌套） | 批次目录下有 `L{lv}-T{n}-{ts}-batch-range/` 子目录 | `telemetry/bot/{batch}/L*-T*-range/` |
| B（扁平） | 批次目录本身就是 tier 目录，CSV 直接在下面 | `telemetry/bot/L{range}-T{n}-{ts}-batch-range/` |

## 数据读取

1. 确认目录含该关（3 种模式匹配）
2. 读 `campaign-summary-*.csv` 的 `winkate` 列（胜率）
3. 读 `campaign-attempts-*.csv` 的 `startDifficulty/ShuffleSplitCount/ShuffleSplitRatios/ShuffleOverflowFactor`（配置参数）
4. `campaign-summary.csv` **无配置参数**——只读它不能说当前 asset 已有 Bot 数据

## 为什么必须查全部 3 种模式

L63 在 `63-63-{ts}` 能找到（模式 1），但还在 `L51-100-T{n}-{ts}-batch-range` 里（模式 3）。只搜模式 1 会漏掉 5 个目录的数据。模式 2（逗号分隔如 `52-53_56`）中的各段也可能是含目标关的。
