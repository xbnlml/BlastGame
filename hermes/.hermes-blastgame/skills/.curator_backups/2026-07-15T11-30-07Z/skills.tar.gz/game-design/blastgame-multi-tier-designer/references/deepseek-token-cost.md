# DeepSeek Token & Cost 说明

## 计费口径差异

| 口径 | Hermes insights | DeepSeek 控制台 |
|------|----------------|-----------------|
| "输入 token" | 只算真正新增的 token | 每次请求的完整上下文 |
| 原因 | Hermes 扣除已缓存/重复部分 | DeepSeek 统计发送的全部 prompt |
| 实际表现 | 输入几M | 输入几百M |

**关键原因：** 每次 API 调用发送完整上下文（系统提示 + tool 定义 + 全部对话历史）。即使部分内容命中缓存，DeepSeek 仍统计全部发送的 token 作为"输入"。

## 定价

### deepseek-v4-flash
| 项目 | 价格/1M tokens |
|------|:-------------:|
| 输入 (cache miss) | $0.14 |
| 输入 (cache hit) | $0.0028 (50x便宜) |
| 输出 | $0.28 |

### deepseek-v4-pro
| 项目 | 价格/1M tokens |
|------|:-------------:|
| 输入 (cache miss) | $0.435 |
| 输入 (cache hit) | $0.003625 |
| 输出 | $0.87 |

## 监控

- `hermes telemetry stats` — 实时 token + 费用监控（需新会话生效）
- `hermes telemetry stats today/week/month` — 不同粒度
- `hermes telemetry budget set global daily 0.01` — 设置预算上限（超支自动停）
- DeepSeek 控制台 — 实际扣费金额，最准确

**插件：** `hermes plugins install nujovich/hermes-telemetry --enable`（已安装）
**自定义计价：** `~/.hermes/telemetry/pricing.yaml` 添加新模型

## 节省 Token

见 SKILL.md Token 优化章节。
