# Unity 管理员弹窗处理

## 背景

以管理员身份启动 Unity 6000.0.60f1 时，会弹出警告对话框：

> "Unity is running with Administrator privileges..."
> 按钮1: "Restart Unity as a standard user"（默认焦点）
> 按钮2: "I wish to continue at my own risk"

必须点击按钮2 才能继续加载。此弹窗**阻塞 Unity 主线程**，PollForRequest 等所有 Editor 回调都不执行。

## 标准流程（先 watchdog 后 Unity）

```bash
# 1. 启动 watchdog
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/watchdog.ps1  # 后台
# 2. 再启动 Unity  
"/c/Program Files/Unity/Hub/Editor/6000.0.60f1/Editor/Unity.exe" -projectPath "C:/Users/Administrator/Documents/BlastGame" -logFile "BuildLogs/unity-launch.log"
# 3. 等 Unity 完成加载（约 60-90 秒）
# 4. 写 auto-batch-request.json
```

## 判定弹窗已关闭

```powershell
Get-Process | Where-Object {$_.MainWindowTitle -like "*administrator*"}
```
无输出 = 弹窗已关。

## 注意事项

- 弹窗出现时 Unity 进程的 MainWindowTitle 固定为 `"Unity is running as administrator."`
- 点击后 Unity 继续加载，需 30-60 秒后才能进入 Editor 主界面
- **Unity 完全加载后再写 request.json**，否则 PollForRequest 还没注册
- Unity 被 `taskkill /F` 杀掉后 Unity Hub 会自动重启，弹窗重新出现
- watchdog.ps1 位于 `Doc/AI/multi-tier-designer/scripts/watchdog.ps1`
