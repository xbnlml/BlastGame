# get_level_data(lv) — 数据检索 API

## 返回值结构

```python
from get_level_data import get_level_data
data = get_level_data(52)

data = {
  'bot':     [{'wr':78.2, 'sd':14, 'sc':5, 'ratios':'1,1,10,1,1', 'of':0.5}, ...],
  'summary': {'batch':'51-75-2026-06-26T23-21-09', 'tiers':[{...}]},
  'phase2':  [{'wr':96.0, 'sd':20, ...}, ...],
  'phase1':  [{'wr':97.0, 'sd':25, ...}, ...],
}
```

## 使用原则

- `data['bot']` 按 wr 降序排列，已按 (sd, sc, ratios, of) 去重
- `data['summary']` 为优化器摘要 5 档（若存在），含 Tier 名称和 VerifiedWinRate
- `data['phase2']` / `data['phase1']` 也按 wr 降序排列，去重
- 如果关号没有某类数据，对应键为 `[]` 或 `None`
- 自动处理嵌套（batch/subdir/file）和扁平（batch/file）两种目录结构
- 自动处理 CSV BOM 和引号字段
- 若 Bot 与 Summary/Phase2 有相同配置，Phase2 中已去重（避免重复计数）
