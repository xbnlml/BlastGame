# campaign-attempts.csv — Bot 运行配置溯源

## 用途

验证 Bot 运行时的实际配置是否等于当前 asset 配置。这是**唯一**能确认 Bot 数据对应哪个配置的方法。

## 文件位置

```
telemetry/bot/<batch>/L<level>-<level>-T<tier>-<timestamp>/campaign-attempts-L<level>-<level>-T<tier>.csv
```

## 关键列（与配置匹配相关）

| 列名 | 含义 | 匹配规则 |
|------|------|---------|
| `startDifficulty` | 起始难度（sd） | 整型直接比较 |
| `shuffleSplitCount` | 洗牌分段数（sc） | 整型直接比较 |
| `shuffleSplitRatios` | 各段难度权重（ratios） | 需 normalize：去空格、逗号分隔、每项转 int |
| `shuffleOverflowFactor` | 跨段参数（of） | float 四舍五入到 3 位小数比较 |
| `tier` | 运行时实际档位 | T1-T5 |
| `won` | 是否通关 | 0/1 |
| `seed` | 独立种子 | — |

## 同目录配套文件

| 文件 | 有配置参数? | 有胜率? |
|------|-----------|---------|
| `campaign-attempts-*.csv` | ✅ sd/sc/ratios/of | ❌ 需从 won 列计算 |
| `campaign-summary-*.csv` | ❌ 无配置信息 | ✅ winkate |

## 常见陷阱

- **campaign-summary.csv 没有配置参数**，只能告诉你胜率，不能告诉你当时用的是哪套配置
- 同一关卡可能有多次 Bot 运行（不同 batch），每次用的 asset 配置可能不同
- 建议取前 3 行确认配置，因为同一 batch 内所有 attempt 的配置应该一致

## 配置匹配示例

```python
def norm_ratios(r):
    if r is None: return ""
    try: return ",".join(str(int(float(x))) for x in str(r).replace(" ","").split(",") if x.strip())
    except: return str(r).replace(" ","").strip()

def cfg_key(sd, sc, ratios, ofv):
    return (int(sd), int(sc), norm_ratios(str(ratios) if ratios else ""), round(float(ofv if ofv else 0), 3))
```
