# 程序化生成关卡 vs 手作关卡

## 如何区分

打开 asset 文件检查行数和内容：

| 特征 | 手作关卡 | 程序化生成关卡 |
|------|---------|---------------|
| 文件大小 | 1000-2000+ 行 | ~47 行 |
| customCellDrawingListV2 | 有（包含所有块 layout） | 无 |
| 牌面显示在 Unity | 可见具体块布局 | 无（运行时生成） |
| 修改方式 | 手工摆块或改 YAML | 只改 DynamicDifficultyConfigs |

## 程序化生成关卡的文件结构（~47 行）

```yaml
%YAML 1.1
...
MonoBehaviour:
  ...
  difficultyLevel: 0
  scoreMultipliers:
  - 1.0
  - ...
  myStack:
    width: 19
    height: 20
    StackHeight: 1
    TowerValue: 40
    PoolValue: 50
    GateSize: 3
    SnakeSize: 80
    DynamicDifficultyConfigs:
    - StartDifficulty: 8
      ShuffleSplitCount: 5
      ShuffleSplitRatios: 1,1,1,1,10
      ShuffleOverflowFactor: 0.5
    - ... (共5个)
```

## 常见陷阱

1. **用 write_file 覆盖 .asset 文件** — 会丢失 customCellDrawingListV2（手作关）或 myStack 参数。必须用 `patch` 只替换 DynamicDifficultyConfigs 块
2. **从 git checkout 恢复** — git 版本可能已经是程序化生成（47行）。不是每一关都有手配牌面
3. **Unity Editor 显示空白** → 检查文件中是否有 customCellDrawingListV2。没有就是正常的程序化生成关卡
4. **优化器全部 100% WR** → 如果是程序化生成关卡，生成算法可能过于简单。提高初始 sd 重试
