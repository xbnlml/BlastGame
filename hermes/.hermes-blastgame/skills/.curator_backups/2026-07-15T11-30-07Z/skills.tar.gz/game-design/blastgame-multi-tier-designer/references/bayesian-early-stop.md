# 贝叶斯自适应停止排查指南

## 现象

多档位优化器瞬间完成（不到1秒），或 Phase 1 产出 90 条配置但全部 100% WR。

## 架构理解

### 仿真 vs 真实 Bot 跑分

Phase 1 使用的是 **SIMULATION（仿真）**，不是真实 Bot 批跑。仿真通过 `BlastBotService.RunSingle()` 在 Unity 编辑器中直接运行，不经过 `BlastBotAutoBatchTrigger`（批跑管线）。

关键区别：
| 维度 | Phase 1 仿真 | 真实 Bot 批跑 |
|------|------------|-------------|
| 引擎 | BlastBotService.RunSingle (async) | BlastBotAutoBatchTrigger (批跑) |
| 运行方式 | Task.Run 多线程 | 批跑管线 + 文件轮询 |
| WR 精度 | 可能偏高 10pp+ | ≈真实 |
| 耗时 | 几分钟 | 20+分钟/关 |

**实测：** L59 Opt 仿真 WR=81-84%，真实 Bot 跑仅 70-74%（差 10pp）。L60 仿真 94-97%，真实 84-89%（差 10pp）。

### 代码路径

`RunEvaluation()` (BlastMultiTierOptimizer.cs:2511):
1. `_evalCache.TryGetValue(cacheKey)` ← 内存缓存命中直接返回
2. `Object.Instantiate(_level)` ← 克隆关卡资源
3. `ApplyCandidateToNeutralTierConfig(simStack, ...)` ← 写入候选配置到 slot 2
4. `BlastBotService.BuildInitialSimulationTemplate(simLevel, options)` ← 构建仿真模板
5. `BlastBotRunPolicy.RunSingleBatchParallel(...)` ← 批量运行仿真（5 个 slot × N 局）
6. 统计 winCount → 写入 `_evalCache` → 返回

### _evalCache 缓存

```csharp
private readonly Dictionary<string, CandidateEvaluation> _evalCache = new();
// cacheKey = candidate.ToKey() + "|n" + runCount + "|" + evalScope;
```

- 实例级（非静态）：每次 new BlastMultiTierOptimizer() → 新空缓存
- 同一 Unity 会话内：第二次跑同一关时，RunSingleBatchParallel 调用 RunSingle 后 Task.Run 异步执行
- **关键：** 缓存包含 runCount 精确匹配（"|n30|" ≠ "|n10|"）

### Phase 1 流程

`Run()` (BlastMultiTierOptimizer.cs:432):
1. Baseline: 用 asset 当前 T3 配置跑 `phase1Runs` 局
2. Round 1: 预设 `Round1PresetCount` 个候选（LHS 采样）
3. Round 2: 自适应（基于 Round 1 结果补缺）
4. Round 3: 自适应（基于全部已有结果补缺）
5. Extension: 如果某档位 InBand 样本 < phase1MinSamplesInTargetBand → 定向补样
6. Reachability check: 每档检查 InBand 样本数 → 不足则停

### 关闭贝叶斯后仍然光速的可能原因

1. **同一 Unity 会话内第二次跑** — `_evalCache` 在内存中，相同 cacheKey 命中
2. **LevelProfileConfig 克隆导致关卡为空** — `Object.Instantiate(_level)` 如果源资产有 data binding 问题，克隆后 Stack/Stage 为空，仿真结果全为 0（WR=0%）或很快结束
3. **关卡牌面为空** — 如果 asset 文件缺少 `customCellDrawingListV2`（被错误批量修改删除），仿真时初始牌面为空 → 直接赢 → WR=100%

### 排查步骤

1. **重启 Unity** — 清除 `_evalCache` 内存缓存
2. **检查 asset 文件行数** — 手作关卡应有 500-2000 行，如有 `customCellDrawingListV2`
3. **关贝叶斯 + 增大每样本局数** — 设 Phase1 每样本局数=200
4. **检查 Editor.log 累加行** — 搜索 `[MultiTierOpt] Cumulative` 看是否真有累加数据
5. **如果所有配置都同 WR** — 说明关卡本身有问题（牌面空/太简单/数据损坏）

### 已知问题

| 问题 | 现象 | 解决 |
|------|------|------|
| 菜面空 | 全部 100% WR，asset 仅 47 行 | 从备份恢复 customCellDrawingListV2 |
| 贝叶斯提前停 | Phase 1 每样本只跑 10 局 | 关掉或增大批大小 |
| 关卡太简单 | 全部 100% WR，L51 早期关 | 增大初始 sd 范围 |
| 关卡太难 | Phase 1 T3 0 个 InBand 样本 | 降低初始 sd |

### 从 Phase 1 原始数据分析

`phase1_raw.csv` 包含所有 80+ 候选配置的 WR。通过它判断：
- 如果 WR 集中在 0-5% → 关卡太难
- 如果 WR 集中在 95-100% → 关卡太简单/排面空
- 如果 WR 分布在 20-80% → 正常范围

`phase1_reachability.csv` 显示每档的 InBand 样本数：
- Passed=True → 该档有足够候选
- ExtensionAbandoned=True → 扩展采样后仍不足，放弃该档
