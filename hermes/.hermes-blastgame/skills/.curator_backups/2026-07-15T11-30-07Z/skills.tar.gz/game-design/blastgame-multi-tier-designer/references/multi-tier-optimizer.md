# 多档位优化器 (BlastMultiTierOptimizer) 行为指南

## 概述

位于 Unity Editor 的 Tools → Blast → GM Workbench → 多档位优化 选项卡。分 Phase 1 (采样)、Phase 2 (组合选择)、Phase 3 (验证) 三个阶段。

## Phase 1 自适应停止（贝叶斯）

新增的贝叶斯自适应停止功能（`_mtBayesAdaptiveStopEnabled`，默认开启）会在每一批模拟后检查后验标准差。

**默认参数：**
- 批大小: 10（每批跑 10 局）
- 停止阈值: 后验标准差 < 0.025

**行为：** 如果标准差 < 0.025，认为当前配置的胜率估算已足够精确，提前停止该配置的后续局数，进入下一配置。\n**副作用：** 在简单关卡（如 L51）上全部 10 局全胜 → 后验标准差立即 < 0.025 → Phase 1 提前结束 → 判定"所有配置都在 75%±20% 范围外" → 优化失败。

**排查要点：**
1. 关掉贝叶斯自适应停止后如果仍然瞬间完成 → 检查关卡 asset 是否为空/程序化生成（48行文件）
2. 如果有 _evalCache 命中（同一 Unity 会话内重复运行）→ 重启 Unity Editor
3. 如果所有采样结果都是 100.0% WR → 关卡可能太简单，需要提高初始 sd

**调试：**
- 查看 Editor.log 中的 `[MultiTierOpt] Cumulative X runs completed` 日志
- Phase1 raw CSV 中的 WinRate 列显示所有采样的 WR

## 输出目录

每次运行在 `telemetry/multi-tier-opt/` 下创建 `{level}-{level}-{timestamp}/` 目录。

关键文件：
- `summary-level-status-{level}-{level}.csv` — 运行结果（success/failed+原因）
- `phase1_raw.csv` — Phase 1 所有采样配置 + WR
- `phase1_reachability.csv` — 各档位可达性分析

## 合批运行

`RunMultiTierOptimizationByRangeFromExcel` 从 `lv_win_config_test.xlsx` 读取目标 WR，按关卡范围逐关运行。
