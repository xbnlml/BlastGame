# Bot Batch Submission

## Request Flow

1. Patch `.asset` file with 5 configs
2. Write `BuildLogs/auto-batch-request.json`
3. Unity auto-detects via `BlastBotAutoBatchTrigger` (triggered by domain reload)
4. To force domain reload: modify a `.cs` file, wait ~20s

## Asset Format Validation

Each tier has exactly 4 parameters. Verify before submitting:

```yaml
- StartDifficulty: <int>
  ShuffleSplitCount: <int>
  ShuffleSplitRatios: <comma-separated numbers>
  ShuffleOverflowFactor: <float>
```

**Common mistake:** `ShuffleSplitRatios` count MUST equal `ShuffleSplitCount`. If SC=5, ratios must be 5 numbers. If SC=4, ratios must be 4 numbers.

**Example check:**
```
SC=5, ratios=1,10,1,1,1  ✅  (5 numbers)
SC=5, ratios=1,1,1,10,1,1  ❌  (6 numbers!)
```

## Triggering Unity from CLI

Cannot open batch-mode Unity while main Editor has the project open (project lock conflict).
Instead, modify a `.cs` file to trigger domain reload → `[InitializeOnLoad]` fires → batch runs.
