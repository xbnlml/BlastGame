# Windows 弹窗/进程排查手册

## 弹窗原因确认流程（不要猜，要监测）

1. **建基线** — `tasklist /FO CSV /NH` 记录当前所有进程
2. **追踪新进程** — 用 WMI 事件订阅（PowerShell），不要轮询 tasklist（太慢）
3. **抓父进程** — 每次新进程出现时查 ParentProcessId，再查父进程名
4. **查生命周期** — 新进程是持续存在还是瞬间消失？偶尔出现还是循环？
5. **结论前必须有证据** — 给出确切 PID、命令、父进程，不说"应该是XX"

## Windows 已知问题

- **Hindsight 文件锁死锁** — `.hindsight/profiles/hermes.lock` 被占用
- **`terminal(background=true)` 弹窗** — Windows 上每次启动新 Python 进程都弹控制台窗口
- **GBK 编码问题** — `pathlib.Path.read_text()` 在中文 Windows 上默认 GBK，UTF-8 文件报错
- **UTF-8 BOM 解决** — `.env` 文件用 `utf-8-sig` 编码（带 BOM），让 `read_text()` 自动识别
- **`pythonw.exe` 仍弹窗** — 即使是无窗口 Python，被 `python.exe`（Hermes agent）spawn 时仍可能显示控制台窗口
- **`execute_code` 无窗口** — 替代 `terminal(background=true)` 的静默方案，在 Hermes 沙箱内执行 Python

## 弹窗实时追踪（不要杀进程先监测）

### 方法一：PowerShell WMI 事件订阅（推荐，捕获父进程）
```powershell
$log = "$env:TEMP\\proc_trace.log"
Register-WmiEvent -Query "SELECT * FROM Win32_ProcessStartTrace" -Action {
    $e = $EventArgs.NewEvent
    if ($e.ProcessName -eq 'python.exe' -or $e.ProcessName -eq 'pythonw.exe') {
        $p = Get-WmiObject Win32_Process -Filter "ProcessId=$($e.ParentProcessID)" -ErrorAction SilentlyContinue
        $ppname = if ($p) { $p.Name } else { "unknown" }
        $c = Get-WmiObject Win32_Process -Filter "ProcessId=$($e.ProcessID)" -ErrorAction SilentlyContinue
        $ccmd = if ($c) { $c.CommandLine } else { "N/A" }
        "$(Get-Date -Format 'HH:mm:ss.fff') $($e.ProcessName) PID=$($e.ProcessID) Parent=$ppname($($e.ParentProcessID)) Cmd=$ccmd" | Out-File -Append $log
    }
} | Out-Null
Start-Sleep -Seconds 300; Unregister-Event -SourceIdentifier (Get-EventSubscriber).Name -Force
```

### 方法二：轮询 tasklist（简单，每2秒采样）
```python
for i in range(90):  # 3 minutes
    r = subprocess.run(['tasklist', ...], capture_output=True)
    # extract python/pids, compare with prev snapshot
    time.sleep(2)
```

### 方法三：批量文件监控（10分钟，每30秒记录控制台进程）
写 bat 文件循环 `tasklist /FI "SESSIONNAME eq Console"` 到日志文件

## Hindsight 故障排除

### 场景一：Daemon 文件锁死锁（启动即报 Resource deadlock）
```
OSError: [Errno 36] Resource deadlock avoided
msvcrt.locking(file_obj.fileno(), msvcrt.LK_LOCK, 1)
```
**原因：** Hermes 进程持有 `.hindsight/profiles/hermes.lock`，daemon 无法获取锁。
**解决：** 关 Hermes → 删 lock 文件 → 外部 CMD 启动 daemon → 开 Hermes
```cmd
taskkill /F /IM python.exe
del %USERPROFILE%\.hindsight\profiles\hermes.lock
hindsight-embed -p hermes daemon start
```

### 场景二：Daemon 启动报 Invalid LLM provider
```
ValueError: Invalid LLM provider: . Must be one of: openai, groq, ollama...
```
**原因：** `config.json` 中 `llm_provider` 被错误设置（如 `"openai_compatible"`）。
**修复：** 改为 `"deepseek"`。同时检查 `hindsight/config.json` 包含：
```json
{
  "llm_provider": "deepseek",
  "llm_api_key": "sk-xxx",
  "llm_base_url": "https://api.deepseek.com/v1",
  "llm_model": "deepseek-chat",
  "mode": "local_embedded"
}
```

### 场景三：Daemon 持续崩溃重启（Hindsight daemon crash loop）
**症状：** pythonw.exe 每 30-60 秒闪退重启，Hermes 自动拉起新实例
**根因：** Hermes agent（`python.exe -m hermes_cli.main serve`）自动管理 daemon 生命周期。daemon 退出（如 idle_timeout=300s）后 agent 立即重启。
**排查：**
```cmd
rem 查 daemon 进程（对比 PIDs 是否变化）
wmic process where "commandline like '%hindsight_api.main%'" get processid,creationdate
rem 查 daemon 日志
type %USERPROFILE%\.hindsight\profiles\hermes.log
```
**解决方式：**
1. 增大 `idle_timeout`（hindsight/config.json 设为 86400，24小时）减少自动退出
2. 或切内存 provider = builtin（停用 daemon）
3. 或从外部 CMD 独立启动 daemon（不依赖 Hermes 管理）

### 场景四：`hermes memory setup` 报 UnicodeDecodeError
```
UnicodeDecodeError: 'gbk' codec can't decode byte 0x94 in position 661
```
**原因：** `.env` 文件有 UTF-8 字符（如 em dash `—`），但 `pathlib.read_text()` 在中文 Windows 上用 GBK 解码。
**修复：**
```python
# 将 .env 保存为 GBK 编码（兼容 read_text）：
with open('.env', 'r', encoding='utf-8-sig') as f:
    content = f.read()
with open('.env', 'w', encoding='gbk') as f:
    f.write(content)
# 或替换所有非 ASCII 字符后再保存
```

### 场景五：`hindsight_retain/recall/reflect` 工具不可用
**原因：** memory provider 被切为 `builtin` 或 `holographic`，而 hindsight 工具仅在 `provider: hindsight` 时注入。
**检查：** `hermes memory status` 确认 Provider 行显示 `hindsight`。
**恢复：** `config.yaml` 中改 `provider: hindsight`，重启 Hermes。

## Gateway 定时任务重启循环

**症状：** 黑窗口每隔1分钟弹出一次

**原因：** `hermes gateway start` 创建了带 `<RestartOnFailure>` 的定时任务
```xml
<RestartOnFailure>
  <Count>999</Count>
  <Interval>PT1M</Interval>
</RestartOnFailure>
```
网关进程被杀后，任务管理器1分钟内自动重启 → 新窗口。

**排查：** `schtasks /query /FO CSV /NH | findstr Hermes`

**根治：**
```
schtasks /delete /TN Hermes_Gateway /F
# 或用自定义 XML 重建（去掉 RestartOnFailure）
```

**注意：** 不要反复 `hermes gateway start` — 它会重建任务。确认不需要网关通知时保持删除状态。

## Unity 批跑触发

**自动触发（推荐）：** `BlastBotAutoBatchTrigger.cs` 的 `PollForRequest()` 通过 `EditorApplication.update` 每5秒轮询 `BuildLogs/auto-batch-request.json`，新文件自动触发 Bot。

**首次/恢复触发：** Unity 在后台时不自动重编译 .cs 文件。写 `Assets/Editor/__ForceReload.cs`（任意内容）到项目目录 → Unity 检测到新文件后触发 domain reload → `[InitializeOnLoad]` 消费 request。约等 20 秒。用完删除。

**备用方案：** 切回 Unity 窗口手动触发。
