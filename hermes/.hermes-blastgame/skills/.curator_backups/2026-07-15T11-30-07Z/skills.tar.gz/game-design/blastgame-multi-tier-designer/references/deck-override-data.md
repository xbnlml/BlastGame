# DeckOverrideData — 手牌覆盖数据

## 是什么

`DeckOverrideData` 是 LevelProfileConfig asset 中 `customCellDrawingListV2` 条目下的一个子结构，控制 Bot 仿真时的初始手牌（卡池）构成。

```yaml
    customCellDrawingListV2:
    - Enabled: 1
      Value: 3
      width: 4
      height: 10
      requiredCount: 20
      DeckOverrideData:
        ExtraLeft: 1
        ExtraLeftType: 1
        Left: 1
        LeftType: 1
        Center: 1
        CenterType: 1
        Right: 1
        RightType: 1
        ExtraRight: 1
        ExtraRightType: 1
```

## 影响

- 影响 Bot 模拟时的初始卡牌生成（`BlastQueueBuilder.cs`：注释 `Stage + DeckOverrideData 生成`）
- 有 vs 无 DeckOverrideData → 初始牌面不同 → Bot 胜率可能变化
- 在恢复 asset 文件时（如从老版覆盖新版），**必须保留 DeckOverrideData**，否则 Bot 结果对不上

## 哪些关有

- 手作关卡（有 customCellDrawingListV2）→ 可能有也可能没有，看关卡设计
- 程序化生成关卡（约 47 行）→ 没有 customCellDrawingListV2 所以也不会有 DeckOverrideData

## 对比方法

```bash
git diff HEAD -- Assets/GameModule/GameMain/ConfigSo/Generated_enum/test/{level}.asset
```

如果 diff 显示 `+DeckOverrideData` → HEAD 版本有，当前文件没有 → 需要从 HEAD 恢复
如果 diff 显示 `-DeckOverrideData` → 当前文件有，HEAD 没有 → 保留当前文件的（可能是老版自带的）

## 从 HEAD 恢复方法

```bash
# 查看 HEAD 中的具体内容
git show HEAD:path/to/{level}.asset | grep -A 20 "DeckOverrideData"
# 按行号插入到当前文件对应位置
```
