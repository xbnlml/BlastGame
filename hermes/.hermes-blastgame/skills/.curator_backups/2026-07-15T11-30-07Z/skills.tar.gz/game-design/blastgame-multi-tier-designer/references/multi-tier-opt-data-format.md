# Multi-Tier Opt Data Format

## 目录结构

```
telemetry/multi-tier-opt/{range}-{date}/
  {level}-{timestamp}/
    phase1_raw.csv            # Phase1 所有候选配置 + 模拟胜率
    phase1_reachability.csv   # 各档可达性分析
    phase2_candidates.csv     # Phase2 各档最优候选列表
    summary.csv               # Phase2 最终结果摘要
    detail.csv                # Phase2 详细结果
    sensitivity.csv           # 敏感性分析
```

## 注意：同一关可能出现在多个 opt 目录

一个关可以有多个 opt 数据：
- **单独跑：** `51-51-2026-07-04T01-15-21/`（单关）
- **批量跑：** `51_58-62_64_68-70-2026-07-04T03-00-33/51-2026-07-04T03-00-33/`（一批）

批量目录命名格式：`{level1}_{level2-range}{level3}_{level4-range}-{timestamp}`
读数据时必须取最新目录，跳过旧的失败跑结果。

## phase1_raw.csv

列：`SampleKind, WinRate, FailCount, TotalRuns, StartDifficulty, ShuffleSplitCount, ShuffleSplitRatios, ShuffleOverflowFactor`

- `SampleKind`: "mandatory"(必须) / "extension"(扩展)
- `WinRate`: 模拟胜率 (0~1)
- `TotalRuns`: 模拟局数（通常 100）
- 其余四列 = 配置参数

## phase1_reachability.csv

列：`Tier, ConfiguredTargetWinRate, BandLow, BandHigh, InBandCount, Required, ExtensionAbandoned, Passed`

- `Tier`: 档位名称（如"T1-超高胜率"）
- `ConfiguredTargetWinRate`: 该档目标胜率
- `BandLow/BandHigh`: 该档可接受胜率区间
- `InBandCount`: 落在区间内的配置数
- `ExtensionAbandoned`: 是否放弃（true=找不到足够配置）
- `Passed`: 是否通过

## phase2_candidates.csv

Phase2 对掉在目标带内的候选配置追加模拟局数，提供更精确的胜率估算。

列：`Tier, WinRate, StartDifficulty, ShuffleSplitCount, ShuffleSplitRatios, ShuffleOverflowFactor`

- `Tier`: 档位标签，如 `TT1-超高胜率`（前缀 TT 表示 tier target）
- `WinRate`: Phase2 追加后的模拟胜率 (0~1)
- 其余四列 = 配置参数

**选择最优配置方法：**
1. 按 `Tier` 分组
2. 每组内按 `WinRate` 排序（降序）
3. 选最接近目标值的配置（非越极端越好）

例如 T1 目标 90%，选 WR 最接近 90% 的，不是 WR 最高的。
T5 目标 60%，选 WR 最接近 60% 的。

**注意：** 这些 WR 是模拟胜率，与实际 Bot 实测可能差 10-20pp。只用做候选排序，最终以 Bot 实测为准。

## summary.csv 和 detail.csv

Phase2 最终结果。

- `summary.csv`: 每档一行，含 tier label + 选用配置 + 预计 WR（模拟）
- `detail.csv`: 每候选一行，更详细

## 快速判断

- `Passed=false` 且 `ExtensionAbandoned=true` → 该档太难，参数调不动
- `Passed=true` → 该档有方案
- 如果 T1 不通过 → Phase2 不做，因为 top-down 依赖
- 通过 Phase1 但无 Phase2 文件 → 优化器停止了（可能是贝叶斯停止触发）
