# BlastBotAutoBatchTrigger — Unity Editor 内自动 Bot 批跑

> 真源: `Assets/GameModule/Editor/Bot/BlastBotAutoBatchTrigger.cs`

## 原理

`[InitializeOnLoad]` 静态构造函数在 Unity Editor domain reload 时注册两个回调：

- `EditorApplication.delayCall += TryRunFromRequestFile` — 启动时立即检查一次
- `EditorApplication.update += PollForRequest` — 每帧轮询

## PollForRequest (轮询)

每 **5 秒**检查一次：

1. `_isRunning` 或正在编译/更新 → 跳过
2. 检查 `BuildLogs/auto-batch-request.json` 是否存在
3. 检查文件的 `LastWriteTime` 是否比上次处理的新
4. 新文件 → 调 `TryRunFromRequestFile`

## TryRunFromRequestFile (执行)

1. 若正在编译 → `delayCall` 再试
2. 读取 `auto-batch-request.json` → 反序列化为 `AutoBatchRequest`
3. 校验：`runCount > 0`、`levelSpec` 有效
4. 创建 `BlastWorkbenchWindow` 实例，调用 `RunBotBatchByLevelRangeForJenkins`
5. 完成后写 `auto-batch-result.json`
6. **删除** `auto-batch-request.json`（标记已消费）

## auto-batch-last-export.txt

执行完毕后，`auto-batch-last-export.txt` 写入 Bot 输出目录的绝对路径。Agent 靠此文件判断 Bot 是否跑完：**轮询该文件 mtime 变化**，不要用固定超时。

## 典型流程

```
Agent 写 request.json → Unity PollForRequest 5s 内拾取 → 跑 Bot
→ 跑完 → 写 result.json → 删 request.json → Agent 发现 result.json
```

## request.json 生命周期陷阱

**request.json 在 Bot 运行期间不会被删除。** 代码执行顺序是：

```
TryRunFromRequestFile:
  1. window.RunBotBatchByLevelRangeForJenkins(...)  ← 耗时数十分钟
  2. WriteResult(...)                                ← 写 result.json
  3. TryDelete(requestPath)                          ← 删 request
```

所以：
- request.json 存在 + result.json 不存在 → **Bot 正在运行中**
- request.json 存在 + result.json 存在 → 可能是上次残留
- request.json 不存在 + result.json 存在 → 正常完成
- 两文件均不存在 → 干净状态

## 通过 Editor.log 监控进度

当 PollForRequest 已拾取但无 result.json 时，Unity Editor.log 是唯一进度源：

```bash
grep "Bot Batch" "$env:LOCALAPPDATA/Unity/Editor/Editor.log" | tail -5
```

日志格式示例：
```
[Bot Batch] Level L52 (0/18): 300 runs × 1 strategy = 300 games
```
`(x/18)` 是当前 tier 内的关卡进度（0-indexed）。Bot 逐关遍历，完成所有关卡的一个 tier 后进入下一 tier。

## 注意事项

- **Unity 必须在运行中**才能拾取（`tasklist | grep Unity.exe` 确认）
- 写 `Assets/Editor/__ForceReload.cs` 可触发 domain reload 加速拾取。**若 Unity 的 AssetDatabase 未自动刷新，touch 一个已存在的 .cs 文件**比创建新文件更可靠
- **不允许**同时跑两个 batchmode Unity 实例（锁冲突）
- `auto-batch-result.json` 会残留上次结果，Agent 提交前应清理
- **中途杀掉 Unity 会丢失所有 Bot 数据**——Bot 只有写 campaign-summary 时才落盘，中间杀进程无数据输出
