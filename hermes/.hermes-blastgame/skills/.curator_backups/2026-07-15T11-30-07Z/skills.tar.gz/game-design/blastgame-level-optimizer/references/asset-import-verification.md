# Asset 导入确认方法

## 问题

patch `.asset` 文件后，Unity 的 AssetDatabase 不会立即刷新。直接写 request.json 会导致 Bot 使用旧缓存配置，白跑一轮。

`touch` + 等固定秒数不可靠（文件监控后台可能不工作）。

## 方法

1. `touch {level}.asset` — 更新文件时间戳
2. 运行 `scripts/activate_unity.ps1` — 聚焦 Unity 窗口触发 AssetDatabase.Refresh
3. **轮询确认导入完成** — 检测 `Logs/AssetImportWorker*.log`，500ms/次，出现 `Start importing ... {level}.asset using Guid(...)` 后继续
4. 写 request.json

## 注意

- AssetImportWorker 日志在 `Logs/AssetImportWorker0.log` 或 `Logs/AssetImportWorker1.log`，**不在** `BuildLogs/unity-launch-test.log`
- 如果 15 秒内无日志，可能文件监控未激活。此时重新聚焦 Unity 再试
- 导入完成后 Bot 开始跑时，还可以通过 `campaign-attempts.csv` 的 startDifficulty 二次验证
