# BlastGame 工具布局 (canonical paths)

> `D:\download\Hermes` 是本项目的工作目录。所有工具、数据、脚本均在此目录下。

## 目录结构

```
D:\download\Hermes\                    ← 工作根目录
├── tools/                              ← 核心工具 (Python)
│   ├── data/
│   │   ├── pool.py                     ← 数据池统一接口 (get_preferred_records, find_best_monotonic)
│   │   └── adapters/
│   │       ├── excel_target.py         ← 读 lv_win_config_test.xlsx 目标胜率
│   │       ├── bot_csv.py              ← 读 telemetry/bot/ CSV
│   │       └── opt_csv.py              ← 读 telemetry/multi-tier-opt/ CSV
│   ├── asset_patcher.py                ← Unity .asset 安全写入 (备份→写入→校验→回滚)
│   ├── find_best_combo.py {lv}         ← 全枚举搜索最佳5档单调组合
│   ├── design_probes.py {lv}           ← 自动评估 phase2 候选设计探针
│   ├── judge_level.py {lv}             ← 单关判级; --scan 51-100 全量扫描
│   ├── validate_combo.py               ← 合格/接近/不合格判定
│   ├── get_level_pool.py               ← 从 telemetry 检索数据
│   ├── dump_level_pools.py             ← 全量刷新 stage-data
│   ├── refresh_pool.py                 ← 增量刷新 stage-data
│   ├── read_target_wr.py               ← 终端展示目标胜率表
│   ├── verify_excel_wr.py              ← Excel vs 池子交叉核对
│   ├── viz_level.py                    ← plotly 可视化
│   ├── stage_status.py                 ← 数据池状态
│   ├── sync_state.py                   ← 三方状态一致性校验
│   ├── check_unity.py                  ← Unity 进程状态检测
│   ├── restart_unity.py                ← 重启 Unity (故障恢复)
│   ├── trigger_unity.py                ← 聚焦+触发编译
│   └── probe_configs.json              ← 全部 50 关的探针配置 (48KB)
│
├── scripts/                            ← 操作脚本 (提交/管道)
│   ├── submit_batch.py "{lv},{lv}"     ← 批量提交 (patch→submit→wait→auto-evaluate)
│   └── run_pipeline.py                 ← 全自动调优管道 (状态机)
│
├── stage-data/{lv}/                    ← 数据池缓存 (每关一个目录)
│   ├── {lv}.bot.json                   ← Bot 验证数据
│   ├── {lv}.assist.json                ← Summary + Phase2 辅助数据
│   └── {lv}.ref.json                   ← Phase1 参考数据
│
├── project-state/
│   ├── board.md                        ← 当前批次状态快照
│   └── timeline.md                     ← 关键事件日志
│
├── asset_backups/                      ← 入库时按日期备份
├── HANDBOOK.md                         ← 完整交接文档
└── 手动挑配置记录_cleaned_final.xlsx     ← 权威入库记录
```

## 外部路径 (游戏工程)

| 内容 | 路径 |
|------|------|
| 关卡 asset | `C:\Users\Administrator\Documents\BlastGame\Assets\...\test\{lv}.asset` |
| 目标胜率表 | `C:\Users\Administrator\Documents\BlastGame\Assets\LvEditorConfig\lv_win_config_test.xlsx` |
| 遥测数据 | `C:\Users\Administrator\Documents\BlastGame\telemetry\bot\` |
| BuildLogs | `C:\Users\Administrator\Documents\BlastGame\BuildLogs\` |

## Agent vs 脚本边界

| Agent 负责 (决策) | 脚本负责 (机械) |
|-------------------|----------------|
| 设计探针方向 (打哪个段) | 从 phase2 枚举候选 (design_probes.py) |
| 裁定边界 case (接近要不要接受) | 全规则检查 (judge_level.py) |
| 根因分析 (为什么 gap 不够) | 最佳组合搜索 (find_best_combo.py) |
| 记录 tuning-records | patch asset + submit + poll (submit_batch.py) |

**原则**: Agent 做分析/决策/设计，脚本只做机械活。不写大自动化脚本替代 agent 判断。
