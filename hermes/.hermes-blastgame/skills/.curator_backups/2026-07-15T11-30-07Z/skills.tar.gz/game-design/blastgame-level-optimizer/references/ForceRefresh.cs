// _ForceRefresh.cs — 强制 Unity AssetDatabase.Refresh
// 用途：patch .asset 后确保 Unity 加载新配置
// 用法：
//   1. 将此文件放入 Assets/Editor/
//   2. touch 一个现有 .cs 文件触发编译
//   3. AppActivate 聚焦 Unity 窗口（关键！）
//   4. 轮询 BuildLogs/_refresh_done.txt 确认完成
//   5. 删除本文件及 .meta
using UnityEditor;
using System.IO;
using UnityEngine;

public static class _ForceRefresh
{
    [InitializeOnLoadMethod]
    static void Refresh()
    {
        AssetDatabase.Refresh();
        var marker = Path.Combine(
            Directory.GetParent(Application.dataPath).FullName,
            "BuildLogs/_refresh_done.txt");
        File.WriteAllText(marker, "done");
    }
}
