---
name: blastgame-level-optimizer
description: "BlastGame 多档位全自动调优管道。全自动=三批流程（决策→执行→裁定），协操=按需调用单模块。"
version: 3.2.0
author: Hermes Agent
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [blastgame, game-design, level-optimizer, pipeline]
    related_skills: [blastgame-multi-tier-designer, blastgame-bot-orchestrator, blastgame-auto-pipeline]
---

# BlastGame 关卡调优

> 工作目录：`D:\download\Hermes\`。游戏工程：`$BLASTGAME_REPO`。

**前置加载：** `blastgame-multi-tier-designer`（规则）+ `blastgame-bot-orchestrator`（批跑提交细节）

---

## 操作守则

0. **所有模式通用：** 操作性动作前先"计划：[操作]"→ 问"要执行吗？"。用户明确批准后才动手。批评/提问/讨论都不是授权。
1. **正常模式：** 执行完展示结果。改完 asset 等后续指令，不自动提交 request。
2. **全自动模式（用户说"全自动/我人不在了/你搞定"）：** 不展示方案、不等确认、不问问题。走三批流程。
3. **不一定同意用户** — 不合理时说出来。
4. **不做用户没要求的事** — 让改 asset 就只改 asset。
5. **白跑不计轮次** — asset 没刷新、配置不对 = 不消耗 6 轮上限。
6. **展示最佳方案再判** — 穷举数据后给用户看，等拍板。
7. **第 6 轮自动结论** — 不合格自动标记接近/改关卡。
8. **禁止随意重启 Unity** — 卡死/崩溃时重启是故障修复。

---

## 模式选择

Agent 首先判断用户当前模式：

| 触发词 | 模式 | 行为 |
|--------|------|------|
| "全自动/自动跑/你搞定/我不在了" | 🔵 全自动 | 三批流程，不等确认 |
| 其他（讨论/问问题/让改某关/让查数据） | 🟢 协操 | 按需调用单模块，等确认 |

---

## 🔵 全自动模式 — 三批流程

```
批A 决策 (Agent)  →  批B 执行 (terminal)  →  批C 裁定 (Agent)
```

### 批A — 决策（Agent 驱动）

**前置检查（Hermes 专有能力，Claude Code 做不到）：**

```bash
# 1. Unity 活着吗？
tasklist /FI "IMAGENAME eq Unity.exe" 2>&1

# 2. 有残留 request 吗？（有 = 上次没跑完）
ls "$BLASTGAME_REPO/BuildLogs/auto-batch-request.json" 2>&1

# 3. 所有目标关的 asset 完整吗？
python -c "from tools.asset_patcher import verify_integrity; [print(f'L{lv}:', verify_integrity(lv)) for lv in [51,52,...]]"
```

三项全过才继续。任一不过 → 修复后再跑，不浪费轮次。

**设计流程：**

1. 读 progress.json 获取全部 pending 关
2. 逐关检索：`tools/data/pool.get_preferred_records(lv)` → 表格展示
3. 改关卡预判（过 judgment-rules.md ⑥）：span<15→改关卡，15-24→可疑，≥25→可跑
4. 命中改关卡 → 标记排除
5. 未命中 → 设计 R1 探針：先调 `design_probes.py` 评估 phase2 候选，agent 定方向，生成配置
6. 写入 `probe_configs.json`

### 批B — 执行（一次性 terminal）

```bash
python D:/download/Hermes/scripts/submit_batch.py "89,90,91,95,99,100" --games 400
```

submit_batch.py 自动完成全部机械操作：
1. 从 probe_configs.json 读配置 → asset_patcher 安全写入
2. `subprocess.Popen` 非阻塞聚焦 Unity → 等 30s 编译
3. 写 request.json → 轮询消费（120s 超时→delete-recreate→重试）→ 等 result.json
4. 自动 `dump_level_pools.py` 刷池子
5. 自动 `find_best_combo.py` 出最佳组合
6. 输出结构化结果

**Agent 不需要插手中间任何步骤。**

卡死处理：submit_batch 超时 → 写 `_stall.json` → agent 读 → 检查 Unity 进程 → 还在则聚焦重试，不在则重启重提交。不跳过关。

### 批C — 裁定（Agent 驱动）

逐关处理：

1. 调 `judge_level.py {lv}` 出结构化判定（确定性规则全自动检查）
2. Agent 只看脚本标记为 ⚠️ 边界/需主观判断的项
3. 加载 judgment-rules.md，对边界 case 裁定：✅合格 / ⚠️接近 / ❌不合格
4. `find_best_combo.py {lv} --top 3` 确认最佳组合
5. 记录到 tuning-records（含全量数据池 + 最佳组合 + 规则判定结果）
6. 更新 progress.json

---

## 🟢 协操模式 — 按需调用单模块

和用户一起工作时，每个模块独立可调。Agent 先展示方案等确认，再执行。

### 模块 1：检索数据

```bash
python D:/download/Hermes/tools/get_level_pool.py {lv}
```
或 Python API：`pool.get_preferred_records(lv)` → `pool.dedup_records(records)`

**输出：** 表格，一档一行（WR/sd/sc/ratios/of/来源/局数），按 WR 降序。

### 模块 2：设计探针

先加载 `probe-design.md`。需要时调 `design_probes.py {lv}` 自动评估 phase2 候选。Agent 做方向决策，脚本算候选。

**输出：** 5 档探针配置表，含预期 WR 和来源。

写入 `probe_configs.json`（供 submit_batch 读取）。

### 模块 3：提交执行（合并原 Step 3/4/5）

```bash
python D:/download/Hermes/scripts/submit_batch.py "72,87,92" --games 200
```

一次调用完成 patch→focus→submit→wait→auto-evaluate。支持 --dry-run 不实际提交只检查。

**手动细粒度操作（偶尔需要时）：**
- patch asset：`tools/asset_patcher.write_ddc(lv, tiers)` 或直接用 `patch` 工具
- 聚焦 Unity：`subprocess.Popen(['powershell','-Command','(New-Object -ComObject WScript.Shell).AppActivate("BlastGame")'])`
- 手动提交：写 request.json → 等消费 → 等 result → 刷池子

### 模块 4：判定

```bash
python D:/download/Hermes/tools/judge_level.py {lv}           # 单关
python D:/download/Hermes/tools/judge_level.py --scan 51-100  # 全量
python D:/download/Hermes/tools/find_best_combo.py {lv} --top 3
```

Agent 加载 judgment-rules.md，对边界 case 裁定。

### 模块 5：入库

1. `asset_patcher.write_ddc(lv, tiers)` → 写入 asset
2. 更新 Excel（`手动挑配置记录_cleaned_final.xlsx`）：
   - **备注规范：** Normal 关 T1 备注涵盖 T1+T2，T3 单独标注，T4 备注涵盖 T4+T5。T2/T5 留空不写（合并单元格视觉关联）
   - 备注内容：数据来源+局数（如 `bot400`、`summary400`、`phase2200`）
   - 写入前先确认所有非空备注正确，**不得留 None**
3. 写入 tuning-records（含全量数据池 + 最佳组合 + 判定结果）
4. 更新 `project-state/board.md`：更新总数 + 从待选配移除
5. 更新 `project-state/timeline.md`：**每关单独一条事件**，格式：
   ```markdown
   ### 🟢 L{lv}入库
   关卡: {lv}（{难度} {目标}）
   配置: sd=... sc=... ratios=... / ...
   WR: ...%（数据来源）
   Asset: 已写入
   ```
   不得将多关合并为一条记录。

---

## 完整工具链

工作目录 `D:\download\Hermes\`。

### 数据层（`tools/data/`）

| 工具 | 用途 |
|------|------|
| `tools/data/pool.py` | 统一数据池接口。`get_preferred_records(lv)` / `find_best_monotonic(records, targets)` / `dedup_records(records)`。**已优化：** Normal 3-tier 窗口剪枝（O(k^3) k≤20），5-tier 内层 gap 预剪，档差评分优先于目标差 |
| `tools/data/adapters/excel_target.py` | 读 `lv_win_config_test.xlsx`，`et.get_target(lv)` 返回目标值+难度 |
| `tools/data/adapters/bot_csv.py` | 读 telemetry/bot/ 实测数据 |
| `tools/data/adapters/opt_csv.py` | 读 telemetry/multi-tier-opt/ 优化器数据 |

### 操作层（`tools/`）

| 工具 | 用途 |
|------|------|
| `tools/asset_patcher.py` | 安全写 Unity asset。`write_ddc(lv, tiers)` 备份→写入→校验→回滚；`verify_integrity(lv)` 完整性检查；`verify_all(lv_list)` 批量检查 |
| `tools/dump_level_pools.py` | 全量刷新 stage-data 缓存 |
| `tools/refresh_pool.py` | 增量刷新 |
| `tools/check_unity.py` | Unity 进程状态（Running/Stopped） |
| `tools/restart_unity.py` | 重启 Unity Editor（故障恢复） |
| `tools/create_progress.py` | progress.json 管理：`init`/`done`/`pending`/`round`/`status` |

### 决策辅助（`tools/`）

| 工具 | 用途 |
|------|------|
| `tools/find_best_combo.py {lv}` | 全枚举找最佳5档单调组合，`--top 3` |
| `tools/judge_level.py {lv}` / `--scan` | 规则检查（确定性检查全自动） |
| `tools/design_probes.py {lv}` | 评估 phase2 候选对池子提升 |
| `tools/validate_combo.py` | 合格/接近/不合格判定 |
| `tools/read_target_wr.py` | 终端展示目标胜率 |
| `tools/verify_excel_wr.py` | Excel vs 池子交叉核对 |
| `tools/viz_level.py` | plotly 可视化 |

### 批跑（`scripts/`）

| 工具 | 用途 |
|------|------|
| `D:/download/Hermes/scripts/submit_batch.py` | **一步到位**：patch→focus→submit→wait→刷池子→auto-evaluate。支持 `--dry-run` `--games 400` |
| `D:/download/Hermes/scripts/run_pipeline.py` | 全自动管道（状态机） |

---

## 参考文件

| 文档 | 位置 | 用途 |
|------|------|------|
| `judgment-rules.md` | `multi-tier-designer/references/` | 判定规则（合格表/硬性违规/审美/改关卡判定） |
| `probe-design.md` | `multi-tier-designer/references/` | 探针设计（需求驱动/调参经验/缺口分析） |
| `stall-recovery.md` | `references/` | 卡死恢复 |
| `pipeline-watchdog.md` | `auto-pipeline/references/` | 管道看门狗 |

---

## 常见错误

1. **检索漏范围模式** — bot/ 目录有单关、逗号、范围 3 种模式，全扫
2. **patch 后不验证** — 提交前 grep 确认 + 跑后读 attempts CSV 比对
3. **Agent 自作主张往前跳** — 只做明确要求的
4. **文字不用表格** — 多档数据必须表格
5. **`write_file` 改 .asset** — 必须用 `patch` 或 `asset_patcher.write_ddc()`
6. **忽略 of 参数** — 四参数全可调，步长 0.02-0.05
7. **跳过 Step 1 直接用 Phase2** — Phase2 WR 是模拟值，优先 Bot 数据
8. **focus Unity 超时** — 用 `subprocess.Popen(DEVNULL)` 非阻塞
9. **轮询 export 混入历史目录** — 只查提交后新出现的目录
10. **TryDelete 失败循环** — 删 request → 评估最新数据 → 写不同 content 重提交
11. **`excel_target` 返回 int key，查询用 str → 全部 miss** — `et.read_targets()` 返回 `{int(lv): {...}}`，但后续 `diff_map.get(str(lv))` 永远查不到，Normal 关回退 hard 跑 5-tier O(n^5) 超慢。统一的修法：存入时 `str(lv_i)` 或查询时 `int(lv)`，二选一全局一致。
12. **board.md 与 Excel 数据不同步** — board 的分类基于记忆/假设，Excel 是真实数据。发现不一致时以 Excel 为准修正 board，不靠猜测。
13. **成品判定忽略数据可靠性** — 组合 gap 达标但数据来源非 bot/summary400（如 phase2、bot100）时，不能直接判 ✅ 合格，应标 ⚠️ 需验证。只有全 bot400/summary400 且 gap 达标才是真合格。
14. **Excel 备注遗漏** — 写入 Excel 后必须逐行检查备注列非空。Normal 关 T1 标注来源（覆盖 T1+T2），T3 单独标注，T4 标注来源（覆盖 T4+T5），T2/T5 留空。写入时若只设了部分行的备注，其余行会残留旧值或 None。
15. **timeline 多关合并** — 每关入库必须单独一条 `### 🟢 L{lv}入库` 记录。不得写成 "L61/L62/L75/L97 四关入库" 合并条目。
16. **submit_batch flow 顺序** — 正确：focus Unity → 等30s编译 → patch asset → 写 request。旧版先 patch 后 focus 导致 Unity 来不及检测文件变更。
17. **request 3次不消费 → 重启 Unity** — 聚焦+delete-recreate 3 次仍不消费，说明 Unity 文件监控/trigger 失活。重启 Unity 是故障恢复，不算随意重启。
18. **全自动模式误入库** — 全自动模式永远不写 asset/Excel/board/timeline，等用户回来核验后说"入库"才执行。只输出 R1/R2 结果供审核，更新 progress.json 的轮次和状态。写入即违规。
19. **判定前漏过硬性违规** — gap 看起来好不代表合格。必须先过硬性违规清单逐条核对（任何档<5%？倒挂？T3锚点？Hard/SuperHard 档差>40%？）。一个命中即 ❌ 不合格，gap 再好也无用。
20. **result.json 不可靠** — Unity 不一定写 result.json。Bot 跑完后 5 档子目录齐但 result.json 可能不存在。submit_batch 超时≠Bot 没跑完。检查：5 档目录齐全 → 手动杀进程 → 刷池子判定。
21. **board 数量不验证** — 入库后总数必须人工核对（原有数+新入数）。25+4=29 不是 28。凭感觉写数字必被骂。
22. **of 是核心杠杆** — R2 探针设计优先考虑 of 梯度探测。L81 池子实战：of=0.107→55% / of=0.5→86%，差值 31pp。用 of 梯度（如 0.15/0.25/0.35）精准探测目标 WR 区间，比调 sd/sc/ratios 有效得多。
23. **R2 探针 5 槽全打缺口** — 不浪费槽位放已验证的 T1/T5 配置。5 个槽放 5 个不同参数变量（如 of 从 0.15→0.4 梯度），一批跑完收获 5 个数据点。Normal 关同理：5 槽全放 T3 方向变体，bot 跑完每个槽都产出缺口段数据。
